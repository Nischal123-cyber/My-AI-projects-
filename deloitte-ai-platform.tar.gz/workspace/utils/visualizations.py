import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def create_dashboard_charts():
    """Create charts for the main dashboard"""
    
    # Lead scoring trend over time
    dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
    lead_scores = np.random.normal(75, 10, 30)
    lead_scores = np.clip(lead_scores, 0, 100)
    
    lead_trend_df = pd.DataFrame({
        'Date': dates,
        'Average_Score': lead_scores,
        'Lead_Count': np.random.randint(80, 150, 30)
    })
    
    lead_scoring_trend = px.line(
        lead_trend_df, x='Date', y='Average_Score',
        title='Lead Scoring Trend (30 Days)',
        labels={'Average_Score': 'Average Lead Score'}
    )
    lead_scoring_trend.update_traces(line=dict(color='#86BC25', width=3))
    lead_scoring_trend.update_layout(
        showlegend=False,
        height=300,
        margin=dict(l=0, r=0, t=40, b=0)
    )
    
    # Sector performance
    sectors = ['Technology', 'Healthcare', 'Finance', 'Manufacturing', 'Retail']
    performance = [85, 78, 82, 70, 75]
    
    sector_performance = px.bar(
        x=sectors, y=performance,
        title='Lead Quality by Sector',
        labels={'x': 'Sector', 'y': 'Average Lead Score'},
        color=performance,
        color_continuous_scale='Viridis'
    )
    sector_performance.update_layout(
        showlegend=False,
        height=300,
        margin=dict(l=0, r=0, t=40, b=0)
    )
    
    # Campaign ROI
    campaigns = ['LinkedIn', 'Google Ads', 'Content', 'Email', 'Events']
    roi_values = [3.2, 2.8, 4.1, 5.2, 2.3]
    
    campaign_roi = px.bar(
        x=campaigns, y=roi_values,
        title='Campaign ROI Performance',
        labels={'x': 'Channel', 'y': 'ROI Multiplier'},
        color=roi_values,
        color_continuous_scale='RdYlGn'
    )
    campaign_roi.update_layout(
        showlegend=False,
        height=300,
        margin=dict(l=0, r=0, t=40, b=0)
    )
    
    # AI Confidence Gauge
    ai_confidence_gauge = go.Figure(go.Indicator(
        mode = "gauge+number+delta",
        value = 87,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': "AI Confidence Score"},
        delta = {'reference': 80},
        gauge = {
            'axis': {'range': [None, 100]},
            'bar': {'color': "#86BC25"},
            'steps': [
                {'range': [0, 50], 'color': "lightgray"},
                {'range': [50, 80], 'color': "yellow"},
                {'range': [80, 100], 'color': "lightgreen"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 90
            }
        }
    ))
    
    ai_confidence_gauge.update_layout(
        height=300,
        margin=dict(l=0, r=0, t=40, b=0)
    )
    
    return {
        'lead_scoring_trend': lead_scoring_trend,
        'sector_performance': sector_performance,
        'campaign_roi': campaign_roi,
        'ai_confidence_gauge': ai_confidence_gauge
    }

def create_lead_scoring_charts():
    """Create charts specific to lead scoring page"""
    
    # Lead score distribution
    scores = np.random.beta(2, 2, 1000) * 100
    
    score_distribution = px.histogram(
        x=scores, nbins=20,
        title='Lead Score Distribution',
        labels={'x': 'Lead Score', 'y': 'Number of Leads'}
    )
    score_distribution.update_traces(marker_color='#86BC25')
    
    # Industry comparison
    industries = ['Technology', 'Healthcare', 'Finance', 'Manufacturing', 'Retail', 'Energy']
    avg_scores = [82, 78, 85, 72, 75, 70]
    lead_counts = [120, 95, 110, 80, 85, 60]
    
    industry_comparison = px.scatter(
        x=lead_counts, y=avg_scores, 
        hover_name=industries,
        size=[15]*len(industries),
        title='Industry Performance: Lead Count vs Average Score',
        labels={'x': 'Number of Leads', 'y': 'Average Score'}
    )
    industry_comparison.update_traces(marker=dict(color='#86BC25', opacity=0.7))
    
    return {
        'score_distribution': score_distribution,
        'industry_comparison': industry_comparison
    }

def create_competitor_charts():
    """Create charts for competitor analysis"""
    
    # Market share pie chart
    competitors = ['Deloitte', 'McKinsey', 'PwC', 'Accenture', 'Others']
    market_shares = [22, 18, 16, 15, 29]
    
    market_share_pie = px.pie(
        values=market_shares, names=competitors,
        title='AI Consulting Market Share',
        color_discrete_sequence=['#86BC25', '#4ECDC4', '#FFE66D', '#FF6B6B', '#95A5A6']
    )
    
    # Competitive positioning
    competitors_data = {
        'Company': ['Deloitte', 'McKinsey', 'PwC', 'Accenture', 'IBM', 'EY'],
        'AI_Capability': [88, 85, 82, 80, 92, 78],
        'Market_Presence': [90, 95, 88, 85, 80, 82],
        'Innovation_Score': [85, 82, 80, 78, 88, 75]
    }
    
    positioning_df = pd.DataFrame(competitors_data)
    
    positioning_chart = px.scatter(
        positioning_df, x='Market_Presence', y='AI_Capability',
        size='Innovation_Score', hover_name='Company',
        title='Competitive Positioning Map',
        labels={'Market_Presence': 'Market Presence', 'AI_Capability': 'AI Capability Score'}
    )
    
    return {
        'market_share_pie': market_share_pie,
        'positioning_chart': positioning_chart
    }

def create_sentiment_charts():
    """Create charts for sentiment analysis"""
    
    # Sentiment timeline
    dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
    sentiment_scores = np.random.normal(0.3, 0.2, 30)
    sentiment_scores = np.clip(sentiment_scores, -1, 1)
    
    sentiment_timeline = px.line(
        x=dates, y=sentiment_scores,
        title='Sentiment Trend Over Time',
        labels={'x': 'Date', 'y': 'Average Sentiment Score'}
    )
    sentiment_timeline.update_traces(line=dict(color='#86BC25', width=3))
    sentiment_timeline.add_hline(y=0, line_dash="dash", line_color="gray")
    
    # Sentiment by source
    sources = ['Client Surveys', 'Social Media', 'Support Tickets', 'Sales Calls', 'Reviews']
    sentiment_by_source = [0.4, 0.2, -0.1, 0.3, 0.25]
    
    sentiment_source_chart = px.bar(
        x=sources, y=sentiment_by_source,
        title='Average Sentiment by Source',
        labels={'x': 'Data Source', 'y': 'Average Sentiment'},
        color=sentiment_by_source,
        color_continuous_scale='RdYlGn'
    )
    
    return {
        'sentiment_timeline': sentiment_timeline,
        'sentiment_source_chart': sentiment_source_chart
    }

def create_market_intelligence_charts():
    """Create charts for market intelligence"""
    
    # Market growth projection
    years = [2024, 2025, 2026, 2027, 2028]
    total_market = [62, 85, 115, 155, 210]
    deloitte_opportunity = [12, 18, 26, 35, 47]
    
    growth_projection = go.Figure()
    growth_projection.add_trace(go.Scatter(
        x=years, y=total_market, mode='lines+markers',
        name='Total Market ($B)', line=dict(color='#4ECDC4', width=3)
    ))
    growth_projection.add_trace(go.Scatter(
        x=years, y=deloitte_opportunity, mode='lines+markers',
        name='Deloitte Opportunity ($B)', line=dict(color='#86BC25', width=3)
    ))
    growth_projection.update_layout(
        title='AI Consulting Market Growth Projection',
        xaxis_title='Year',
        yaxis_title='Market Size ($B)'
    )
    
    # Regional analysis
    regions = ['North America', 'Europe', 'Asia Pacific', 'Latin America', 'Middle East']
    market_sizes = [35.2, 22.8, 24.1, 3.2, 2.2]
    growth_rates = [25.3, 28.7, 32.1, 35.8, 31.2]
    
    regional_analysis = px.scatter(
        x=market_sizes, y=growth_rates,
        size=[15]*len(regions), hover_name=regions,
        title='Regional Market Analysis: Size vs Growth Rate',
        labels={'x': 'Market Size ($B)', 'y': 'Growth Rate (%)'}
    )
    
    return {
        'growth_projection': growth_projection,
        'regional_analysis': regional_analysis
    }

def create_campaign_charts():
    """Create charts for campaign optimization"""
    
    # ROI by channel
    channels = ['LinkedIn', 'Google Ads', 'Content Marketing', 'Email', 'Webinars', 'Events']
    roi_values = [3.2, 2.8, 4.1, 5.2, 2.9, 2.3]
    
    roi_chart = px.bar(
        x=channels, y=roi_values,
        title='ROI by Marketing Channel',
        labels={'x': 'Channel', 'y': 'ROI Multiplier'},
        color=roi_values,
        color_continuous_scale='Viridis'
    )
    
    # Budget allocation optimization
    budget_allocation = {
        'LinkedIn': 35,
        'Google Ads': 25,
        'Content Marketing': 20,
        'Email': 10,
        'Events': 10
    }
    
    budget_pie = px.pie(
        values=list(budget_allocation.values()),
        names=list(budget_allocation.keys()),
        title='Optimized Budget Allocation (%)'
    )
    
    return {
        'roi_chart': roi_chart,
        'budget_pie': budget_pie
    }
