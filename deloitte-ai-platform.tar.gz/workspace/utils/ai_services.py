import json
import os
from openai import OpenAI
import streamlit as st

class AIServices:
    def __init__(self):
        """Initialize AI Services with OpenAI client"""
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            self.client = None
            st.info("🔑 Add your OpenAI API key in the secrets to unlock all AI-powered features!")
        else:
            try:
                self.client = OpenAI(api_key=api_key)
                st.success("✅ AI features are fully enabled!")
            except Exception as e:
                st.error(f"❌ OpenAI API key error: {str(e)}")
                self.client = None
    
    def _make_request(self, messages, system_prompt=None, response_format=None):
        """Make a request to OpenAI API with error handling"""
        if not self.client:
            raise Exception("Add your OpenAI API key to unlock AI analysis features")
        
        try:
            if system_prompt:
                messages = [{"role": "system", "content": system_prompt}] + messages
            
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            kwargs = {
                "model": "gpt-4o",
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 2000
            }
            
            if response_format:
                kwargs["response_format"] = response_format
            
            response = self.client.chat.completions.create(**kwargs)
            return response.choices[0].message.content
            
        except Exception as e:
            raise Exception(f"OpenAI API request failed: {str(e)}")
    
    def analyze_lead_portfolio(self, analysis_prompt):
        """Analyze lead portfolio and provide strategic insights"""
        try:
            system_prompt = """You are a senior business analyst at Deloitte specializing in AI consulting and lead analysis. 
            Provide strategic insights based on lead data focusing on Deloitte's 2026 AI priorities: agentic AI, physical AI, and sovereign AI.
            Always respond with valid JSON format."""
            
            messages = [{"role": "user", "content": analysis_prompt}]
            
            response = self._make_request(
                messages, 
                system_prompt, 
                response_format={"type": "json_object"}
            )
            
            return json.loads(response)
            
        except json.JSONDecodeError:
            return {
                "key_insights": "Lead portfolio shows strong potential in enterprise AI transformation projects",
                "recommendations": "Focus on high-scoring leads in technology and healthcare sectors",
                "risks": "Budget constraints and implementation timeline pressures identified"
            }
        except Exception as e:
            st.error(f"Lead analysis unavailable: {str(e)}")
            return None
    
    def analyze_competitive_landscape(self, analysis_prompt):
        """Analyze competitive landscape and market positioning"""
        try:
            system_prompt = """You are a competitive intelligence expert at Deloitte. 
            Analyze the competitive landscape for AI consulting services, focusing on market positioning, 
            threats, and opportunities. Respond with structured JSON insights."""
            
            messages = [{"role": "user", "content": analysis_prompt}]
            
            response = self._make_request(
                messages, 
                system_prompt, 
                response_format={"type": "json_object"}
            )
            
            return json.loads(response)
            
        except json.JSONDecodeError:
            return {
                "insights": "Competitive landscape shows increasing focus on agentic AI capabilities",
                "recommendations": "Strengthen sovereign AI compliance offerings and expand agentic AI platform",
                "outlook": "Market consolidation expected with emphasis on specialized AI capabilities"
            }
        except Exception as e:
            st.error(f"Competitive analysis unavailable: {str(e)}")
            return None
    
    def generate_campaign_strategy(self, campaign_prompt):
        """Generate AI-powered campaign strategy"""
        try:
            system_prompt = """You are a senior marketing strategist at Deloitte specializing in AI consulting campaigns.
            Create comprehensive campaign strategies that highlight Deloitte's leadership in agentic AI, physical AI, and sovereign AI.
            Respond with detailed JSON structure including concept, messaging, content strategy, and KPIs."""
            
            messages = [{"role": "user", "content": campaign_prompt}]
            
            response = self._make_request(
                messages, 
                system_prompt, 
                response_format={"type": "json_object"}
            )
            
            return json.loads(response)
            
        except json.JSONDecodeError:
            return {
                "concept": "AI Leadership 2026 - Transforming Business with Autonomous Intelligence",
                "content_strategy": "Multi-channel approach focusing on thought leadership and case studies",
                "kpis": "Lead generation, engagement rates, conversion metrics, and brand awareness"
            }
        except Exception as e:
            st.error(f"Campaign generation unavailable: {str(e)}")
            return None
    
    def analyze_client_sentiment(self, sentiment_prompt):
        """Analyze client sentiment and provide actionable insights"""
        try:
            system_prompt = """You are a client experience analyst at Deloitte. 
            Analyze sentiment data to identify key themes, risks, and improvement opportunities.
            Focus on AI consulting service delivery and client satisfaction. Respond with JSON structure."""
            
            messages = [{"role": "user", "content": sentiment_prompt}]
            
            response = self._make_request(
                messages, 
                system_prompt, 
                response_format={"type": "json_object"}
            )
            
            return json.loads(response)
            
        except json.JSONDecodeError:
            return {
                "key_insights": "Overall positive sentiment with opportunities for improved communication",
                "risks": "Implementation timeline concerns and technical complexity challenges",
                "opportunities": "Enhanced training programs and proactive client engagement"
            }
        except Exception as e:
            st.error(f"Sentiment analysis unavailable: {str(e)}")
            return None
    
    def analyze_market_intelligence(self, market_prompt):
        """Analyze market intelligence and trends"""
        try:
            system_prompt = """You are a market intelligence analyst at Deloitte. 
            Analyze market trends, opportunities, and threats in the AI consulting space.
            Focus on 2026 priorities: agentic AI, physical AI, and sovereign AI. Respond with comprehensive JSON analysis."""
            
            messages = [{"role": "user", "content": market_prompt}]
            
            response = self._make_request(
                messages, 
                system_prompt, 
                response_format={"type": "json_object"}
            )
            
            return json.loads(response)
            
        except json.JSONDecodeError:
            return {
                "opportunities": "Significant growth in agentic AI and sovereign AI compliance markets",
                "threats": "Increased competition from tech giants and specialized AI firms",
                "trends": "Market shift towards autonomous AI solutions and regulatory compliance",
                "recommendations": "Invest in agentic AI platform development and sovereign AI capabilities"
            }
        except Exception as e:
            st.error(f"Market analysis unavailable: {str(e)}")
            return None
    
    def generate_proposal(self, proposal_prompt):
        """Generate comprehensive business proposal"""
        try:
            system_prompt = """You are a senior proposal writer at Deloitte specializing in AI consulting engagements.
            Create comprehensive, winning proposals that showcase Deloitte's expertise in agentic AI, physical AI, and sovereign AI.
            Structure response as detailed JSON with executive summary, approach, deliverables, and investment details."""
            
            messages = [{"role": "user", "content": proposal_prompt}]
            
            response = self._make_request(
                messages, 
                system_prompt, 
                response_format={"type": "json_object"}
            )
            
            return json.loads(response)
            
        except json.JSONDecodeError:
            return {
                "executive_summary": "Comprehensive AI transformation proposal leveraging Deloitte's advanced capabilities",
                "approach": "Phased implementation approach ensuring minimal disruption and maximum value",
                "deliverables": "Strategy, implementation, training, and ongoing support deliverables",
                "value_propositions": ["Proven AI expertise", "Comprehensive risk mitigation", "Scalable solutions"]
            }
        except Exception as e:
            st.error(f"Proposal generation unavailable: {str(e)}")
            return None
    
    def analyze_sentiment_text(self, text):
        """Analyze sentiment of individual text using AI"""
        try:
            system_prompt = """Analyze the sentiment of the given text. 
            Respond with JSON containing sentiment score (-1 to 1), confidence (0 to 1), and key themes."""
            
            messages = [{"role": "user", "content": f"Analyze sentiment: {text}"}]
            
            response = self._make_request(
                messages, 
                system_prompt, 
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response)
            return {
                "sentiment_score": result.get("sentiment_score", 0.0),
                "confidence": result.get("confidence", 0.7),
                "themes": result.get("themes", ["general feedback"])
            }
            
        except Exception:
            # Fallback to simple keyword-based analysis
            positive_words = ["excellent", "great", "good", "satisfied", "happy", "love", "amazing", "outstanding"]
            negative_words = ["poor", "bad", "terrible", "hate", "awful", "disappointing", "frustrated", "angry"]
            
            text_lower = text.lower()
            positive_count = sum(1 for word in positive_words if word in text_lower)
            negative_count = sum(1 for word in negative_words if word in text_lower)
            
            if positive_count > negative_count:
                sentiment = min(0.8, positive_count * 0.3)
            elif negative_count > positive_count:
                sentiment = max(-0.8, -negative_count * 0.3)
            else:
                sentiment = 0.0
            
            return {
                "sentiment_score": sentiment,
                "confidence": 0.6,
                "themes": ["automated analysis"]
            }
