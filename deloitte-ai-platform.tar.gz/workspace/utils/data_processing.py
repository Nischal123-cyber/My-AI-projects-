import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

def load_dashboard_metrics():
    """Load key dashboard metrics for the main page"""
    return {
        'active_leads': 1247,
        'leads_delta': 156,
        'conversion_rate': 24.3,
        'conversion_delta': 2.1,
        'pipeline_value': 18500000,
        'pipeline_delta': 12.8,
        'ai_confidence': 87
    }

def generate_lead_data(num_leads=50):
    """Generate realistic lead data for analysis"""
    industries = ['Technology', 'Healthcare', 'Financial Services', 'Manufacturing', 'Retail', 'Energy', 'Government']
    company_sizes = ['Enterprise', 'Mid-market', 'Small']
    engagement_levels = ['High', 'Medium', 'Low']
    
    # Create realistic company names
    tech_prefixes = ['Tech', 'Data', 'AI', 'Smart', 'Digital', 'Cyber', 'Cloud', 'Innovation']
    suffixes = ['Corp', 'Inc', 'Solutions', 'Systems', 'Dynamics', 'Ventures', 'Partners', 'Group']
    
    leads = []
    for i in range(num_leads):
        company_name = f"{random.choice(tech_prefixes)}{random.choice(suffixes)} {random.randint(100, 999)}"
        
        lead = {
            'lead_id': f'L{1000 + i}',
            'company_name': company_name,
            'industry': random.choice(industries),
            'company_size': random.choice(company_sizes),
            'estimated_budget': random.randint(50000, 2000000),
            'engagement_level': random.choice(engagement_levels),
            'last_engagement': (datetime.now() - timedelta(days=random.randint(1, 30))).strftime('%Y-%m-%d'),
            'contact_name': f"Contact {i+1}",
            'source': random.choice(['Website', 'Referral', 'Event', 'Cold Outreach', 'Social Media']),
            'project_type': random.choice(['AI Strategy', 'Digital Transformation', 'Data Analytics', 'Cloud Migration', 'Automation'])
        }
        leads.append(lead)
    
    return pd.DataFrame(leads)

def calculate_lead_score(lead_row, industry_weight=0.3, size_weight=0.25, engagement_weight=0.25, budget_weight=0.2):
    """Calculate lead score based on various factors"""
    score = 0
    
    # Industry scoring (higher for target industries)
    target_industries = ['Technology', 'Healthcare', 'Financial Services']
    if lead_row['industry'] in target_industries:
        score += 30 * industry_weight
    else:
        score += 20 * industry_weight
    
    # Company size scoring
    size_scores = {'Enterprise': 30, 'Mid-market': 25, 'Small': 15}
    score += size_scores.get(lead_row['company_size'], 20) * size_weight
    
    # Engagement level scoring
    engagement_scores = {'High': 30, 'Medium': 20, 'Low': 10}
    score += engagement_scores.get(lead_row['engagement_level'], 15) * engagement_weight
    
    # Budget scoring (logarithmic scale)
    budget = lead_row['estimated_budget']
    if budget >= 1000000:
        budget_score = 30
    elif budget >= 500000:
        budget_score = 25
    elif budget >= 200000:
        budget_score = 20
    else:
        budget_score = 10
    
    score += budget_score * budget_weight
    
    # Add some randomness to simulate other factors
    score += random.uniform(-5, 15)
    
    return min(100, max(0, score))

def generate_competitor_data():
    """Generate competitor analysis data"""
    competitors = [
        'McKinsey & Company',
        'PwC',
        'Accenture',
        'IBM Consulting',
        'EY',
        'KPMG',
        'BCG',
        'Capgemini',
        'Cognizant',
        'TCS'
    ]
    
    competitor_data = []
    for company in competitors:
        data = {
            'company_name': company,
            'market_share': random.uniform(5, 25),
            'ai_capability_score': random.randint(60, 95),
            'revenue_millions': random.randint(1000, 50000),
            'growth_rate': random.uniform(-2, 35),
            'threat_level': random.choice(['High', 'Medium', 'Low']),
            'strengths': random.choice(['AI Expertise', 'Market Reach', 'Brand Recognition', 'Innovation', 'Pricing']),
            'recent_wins': random.randint(2, 15)
        }
        competitor_data.append(data)
    
    return pd.DataFrame(competitor_data)

def generate_campaign_data():
    """Generate campaign performance data"""
    channels = ['LinkedIn', 'Google Ads', 'Content Marketing', 'Email Marketing', 'Webinars', 'Events']
    
    campaigns = []
    for i, channel in enumerate(channels):
        campaign = {
            'campaign_id': f'C{2024000 + i}',
            'campaign_name': f'{channel} AI Leadership Campaign',
            'channel': channel,
            'spend': random.randint(10000, 100000),
            'leads_generated': random.randint(50, 500),
            'conversion_rate': random.uniform(1.5, 8.0),
            'roi': random.uniform(1.2, 4.5),
            'cost_per_lead': random.randint(45, 250),
            'start_date': (datetime.now() - timedelta(days=random.randint(30, 180))).strftime('%Y-%m-%d'),
            'status': random.choice(['Active', 'Paused', 'Completed'])
        }
        campaigns.append(campaign)
    
    return pd.DataFrame(campaigns)

def predict_campaign_performance(budget, duration_weeks, audience_size, channels):
    """Predict campaign performance based on inputs"""
    
    # Base performance metrics
    base_cpl = 85  # Base cost per lead
    base_conversion = 3.2  # Base conversion rate
    
    # Channel multipliers
    channel_multipliers = {
        'LinkedIn': {'cpl': 1.2, 'conversion': 1.3},
        'Google Ads': {'cpl': 0.8, 'conversion': 0.9},
        'Content Marketing': {'cpl': 1.5, 'conversion': 1.8},
        'Email': {'cpl': 0.4, 'conversion': 2.1},
        'Webinars': {'cpl': 2.0, 'conversion': 2.5},
        'Events': {'cpl': 3.0, 'conversion': 3.2}
    }
    
    # Calculate weighted averages based on selected channels
    if channels:
        avg_cpl_multiplier = sum(channel_multipliers.get(ch, {'cpl': 1.0})['cpl'] for ch in channels) / len(channels)
        avg_conversion_multiplier = sum(channel_multipliers.get(ch, {'conversion': 1.0})['conversion'] for ch in channels) / len(channels)
    else:
        avg_cpl_multiplier = 1.0
        avg_conversion_multiplier = 1.0
    
    # Adjust for audience size (economies of scale)
    audience_factor = min(1.5, 1 + (audience_size - 100000) / 1000000)
    
    # Calculate predictions
    predicted_cpl = base_cpl * avg_cpl_multiplier / audience_factor
    predicted_conversion = base_conversion * avg_conversion_multiplier
    
    total_leads = int(budget / predicted_cpl)
    expected_roi = (total_leads * predicted_conversion * 5000) / budget  # Assuming $5K value per conversion
    
    return {
        'total_leads': total_leads,
        'weekly_leads': total_leads // duration_weeks,
        'cost_per_lead': predicted_cpl,
        'conversion_rate': predicted_conversion,
        'expected_roi': expected_roi,
        'confidence': random.randint(75, 90)
    }

def generate_client_feedback_data():
    """Generate client feedback data for sentiment analysis"""
    
    feedback_templates = [
        "The AI implementation exceeded our expectations and delivered {outcome}",
        "Working with Deloitte on our {project_type} has been {sentiment_word}",
        "The team's expertise in {technology} helped us achieve {result}",
        "Communication throughout the {project_type} project was {quality}",
        "The ROI from our AI transformation has been {performance}"
    ]
    
    positive_words = ["excellent", "outstanding", "impressive", "professional", "thorough"]
    negative_words = ["challenging", "difficult", "concerning", "disappointing", "problematic"]
    neutral_words = ["adequate", "standard", "acceptable", "reasonable", "typical"]
    
    outcomes = ["significant cost savings", "improved efficiency", "better insights", "streamlined processes", "enhanced capabilities"]
    project_types = ["AI strategy", "digital transformation", "automation", "data analytics", "cloud migration"]
    technologies = ["machine learning", "agentic AI", "data analytics", "cloud platforms", "automation tools"]
    results = ["our business goals", "measurable improvements", "competitive advantage", "operational excellence", "strategic objectives"]
    qualities = ["clear and timely", "professional", "comprehensive", "detailed", "responsive"]
    performances = ["exceptional", "above expectations", "significant", "measurable", "transformational"]
    
    feedback_data = []
    for i in range(25):
        # Determine sentiment bias (70% positive, 20% neutral, 10% negative)
        sentiment_type = random.choices(['positive', 'neutral', 'negative'], weights=[70, 20, 10])[0]
        
        if sentiment_type == 'positive':
            sentiment_word = random.choice(positive_words)
        elif sentiment_type == 'negative':
            sentiment_word = random.choice(negative_words)
        else:
            sentiment_word = random.choice(neutral_words)
        
        template = random.choice(feedback_templates)
        feedback_text = template.format(
            outcome=random.choice(outcomes),
            project_type=random.choice(project_types),
            sentiment_word=sentiment_word,
            technology=random.choice(technologies),
            result=random.choice(results),
            quality=random.choice(qualities),
            performance=random.choice(performances)
        )
        
        feedback = {
            'feedback_id': f'F{3000 + i}',
            'client_name': f'Client Corp {i+1}',
            'project_type': random.choice(project_types),
            'feedback_text': feedback_text,
            'date': (datetime.now() - timedelta(days=random.randint(1, 90))).strftime('%Y-%m-%d'),
            'rating': random.randint(1, 5) if sentiment_type == 'positive' else random.randint(3, 5) if sentiment_type == 'neutral' else random.randint(1, 3)
        }
        feedback_data.append(feedback)
    
    return pd.DataFrame(feedback_data)

def generate_social_media_data():
    """Generate social media sentiment data"""
    
    platforms = ['LinkedIn', 'Twitter', 'Reddit', 'Industry Forums']
    post_templates = [
        "Just completed an AI project with @Deloitte - {sentiment}",
        "Deloitte's approach to {topic} is {adjective}",
        "Attending Deloitte AI conference - {experience}",
        "Their expertise in {area} really {verb} our expectations",
        "Working with Deloitte on {project} has been {outcome}"
    ]
    
    positive_adjectives = ["impressive", "excellent", "outstanding", "innovative", "comprehensive"]
    negative_adjectives = ["disappointing", "challenging", "concerning", "limited", "expensive"]
    neutral_adjectives = ["standard", "typical", "adequate", "reasonable", "professional"]
    
    topics = ["agentic AI", "digital transformation", "data strategy", "AI governance", "automation"]
    areas = ["machine learning", "data analytics", "AI strategy", "implementation", "consulting"]
    projects = ["AI transformation", "digital strategy", "automation", "analytics", "cloud migration"]
    
    social_data = []
    for i in range(30):
        sentiment_type = random.choices(['positive', 'neutral', 'negative'], weights=[60, 25, 15])[0]
        
        if sentiment_type == 'positive':
            adjective = random.choice(positive_adjectives)
            sentiment = "really impressed with the results"
            experience = "learning a lot about AI innovation"
            verb = "exceeded"
            outcome = "transformational"
        elif sentiment_type == 'negative':
            adjective = random.choice(negative_adjectives)
            sentiment = "had some challenges to work through"
            experience = "hoping for more practical insights"
            verb = "fell short of"
            outcome = "mixed results"
        else:
            adjective = random.choice(neutral_adjectives)
            sentiment = "progressing well overall"
            experience = "getting good insights"
            verb = "met"
            outcome = "as expected"
        
        template = random.choice(post_templates)
        content = template.format(
            sentiment=sentiment,
            topic=random.choice(topics),
            adjective=adjective,
            experience=experience,
            area=random.choice(areas),
            verb=verb,
            project=random.choice(projects),
            outcome=outcome
        )
        
        post = {
            'post_id': f'S{4000 + i}',
            'platform': random.choice(platforms),
            'content': content,
            'date': (datetime.now() - timedelta(days=random.randint(1, 60))).strftime('%Y-%m-%d'),
            'engagement': random.randint(5, 500),
            'author_type': random.choice(['Client', 'Industry Expert', 'Employee', 'Prospect'])
        }
        social_data.append(post)
    
    return pd.DataFrame(social_data)

def generate_market_trends_data():
    """Generate market trends data"""
    
    trends = [
        'Agentic AI Adoption',
        'Sovereign AI Compliance',
        'Physical AI Integration',
        'AI Governance Standards',
        'Generative AI Enterprise Use',
        'AI Ethics Frameworks',
        'Edge AI Deployment',
        'AI-Human Collaboration'
    ]
    
    trend_data = []
    for trend in trends:
        data = {
            'trend_name': trend,
            'current_adoption': random.uniform(10, 70),
            'growth_rate': random.uniform(15, 45),
            'market_impact': random.uniform(60, 95),
            'deloitte_readiness': random.uniform(65, 90),
            'investment_required': random.uniform(5, 25),
            'time_to_market': random.randint(6, 24)
        }
        trend_data.append(data)
    
    return pd.DataFrame(trend_data)

def generate_industry_data():
    """Generate industry-specific data"""
    
    industries = ['Technology', 'Healthcare', 'Financial Services', 'Manufacturing', 'Retail', 'Energy']
    
    industry_data = []
    for industry in industries:
        data = {
            'industry': industry,
            'ai_maturity': random.uniform(40, 85),
            'spending_growth': random.uniform(20, 40),
            'deloitte_presence': random.uniform(50, 90),
            'opportunity_size': random.uniform(2, 15),
            'competitive_intensity': random.choice(['High', 'Medium', 'Low']),
            'key_use_cases': random.choice(['Process Automation', 'Predictive Analytics', 'Customer Experience', 'Risk Management'])
        }
        industry_data.append(data)
    
    return pd.DataFrame(industry_data)
