import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from utils.ai_services import AIServices
from utils.visualizations import create_dashboard_charts
from utils.data_processing import load_dashboard_metrics

# Page configuration
st.set_page_config(
    page_title="Deloitte AI Marketing Intelligence Platform",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for Deloitte branding
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #86BC25 0%, #43B02A 100%);
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 4px solid #86BC25;
    }
    .insight-box {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid #e9ecef;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize AI Services
ai_services = AIServices()

# Main header
st.markdown("""
<div class="main-header">
    <h1 style="color: white; margin: 0;">🚀 Deloitte AI Marketing Intelligence Platform</h1>
    <p style="color: white; margin: 0; font-size: 1.2em;">Autonomous Marketing Intelligence powered by Agentic AI for 2026</p>
</div>
""", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.markdown("""
    <div style="background: linear-gradient(45deg, #86BC25, #43B02A); padding: 20px; border-radius: 10px; text-align: center; margin-bottom: 20px;">
        <h2 style="color: white; margin: 0; font-weight: bold;">DELOITTE</h2>
        <p style="color: white; margin: 0; font-size: 14px;">AI Intelligence Platform</p>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("### 🎯 AI Priorities 2026")
    st.markdown("**Agentic AI**: Autonomous marketing workflows")
    st.markdown("**Physical AI**: IoT & sensor integration")
    st.markdown("**Sovereign AI**: Data governance & compliance")
    
    # API Key status and setup guide
    import os
    if os.getenv("OPENAI_API_KEY"):
        st.success("🤖 AI Features: Active")
        st.info("All advanced AI analysis features enabled")
    else:
        st.warning("🔑 AI Features: Add API Key")
        with st.expander("📋 Quick Setup Guide"):
            st.markdown("""
            **To unlock all AI features:**
            
            1. Visit [OpenAI Platform](https://platform.openai.com)
            2. Create account & add $5 credits
            3. Generate API key 
            4. In Replit: Secrets tab → Add `OPENAI_API_KEY`
            5. Restart application
            
            **AI Features Available:**
            - Advanced sentiment analysis
            - Market intelligence reports  
            - AI proposal generation
            - Strategic recommendations
            """)
        
        if st.button("🔗 Open OpenAI Platform"):
            st.markdown('[Click here to open OpenAI Platform](https://platform.openai.com)')
            
        if st.button("📖 View Detailed Setup Guide"):
            with open("API_SETUP_GUIDE.md", "r") as f:
                guide_content = f.read()
            st.markdown(guide_content)
    
    st.markdown("---")
    st.markdown("### 📊 Platform Features")
    st.markdown("- Lead Scoring & Qualification")
    st.markdown("- Competitor Intelligence")
    st.markdown("- Campaign Optimization")
    st.markdown("- Sentiment Analysis")
    st.markdown("- Market Intelligence")
    st.markdown("- AI Proposal Generation")

# Load dashboard metrics
metrics_data = load_dashboard_metrics()

# Key Metrics Row
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.metric(
        label="📈 Active Leads",
        value=f"{metrics_data['active_leads']:,}",
        delta=f"+{metrics_data['leads_delta']} from last month"
    )
    st.markdown('</div>', unsafe_allow_html=True)

with col2:
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.metric(
        label="🎯 Conversion Rate",
        value=f"{metrics_data['conversion_rate']:.1f}%",
        delta=f"+{metrics_data['conversion_delta']:.1f}%"
    )
    st.markdown('</div>', unsafe_allow_html=True)

with col3:
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.metric(
        label="💰 Revenue Pipeline",
        value=f"${metrics_data['pipeline_value']:,.0f}",
        delta=f"+{metrics_data['pipeline_delta']:.1f}%"
    )
    st.markdown('</div>', unsafe_allow_html=True)

with col4:
    st.markdown('<div class="metric-card">', unsafe_allow_html=True)
    st.metric(
        label="🤖 AI Confidence",
        value=f"{metrics_data['ai_confidence']:.0f}%",
        delta="+2.3%"
    )
    st.markdown('</div>', unsafe_allow_html=True)

# Real-time AI Insights
st.markdown("### 🧠 Real-time AI Insights")

col1, col2 = st.columns(2)

with col1:
    st.markdown('<div class="insight-box">', unsafe_allow_html=True)
    st.markdown("**🚨 Market Alert**")
    st.markdown("AI detected 23% increase in 'digital transformation consulting' searches in the technology sector. Recommend increasing campaign spend by 15%.")
    st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('<div class="insight-box">', unsafe_allow_html=True)
    st.markdown("**🎯 Lead Quality Alert**")
    st.markdown("High-value leads from healthcare sector showing 85% qualification score. Autonomous agent has prioritized 12 leads for immediate follow-up.")
    st.markdown('</div>', unsafe_allow_html=True)

with col2:
    st.markdown('<div class="insight-box">', unsafe_allow_html=True)
    st.markdown("**📊 Campaign Performance**")
    st.markdown("AI-optimized campaigns showing 34% better performance than traditional campaigns. Predictive model suggests 2.3x ROI improvement.")
    st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('<div class="insight-box">', unsafe_allow_html=True)
    st.markdown("**🔍 Competitor Intelligence**")
    st.markdown("Competitor analysis reveals new AI service offerings. Opportunity identified in sustainable technology consulting market.")
    st.markdown('</div>', unsafe_allow_html=True)

# Dashboard Charts
st.markdown("### 📈 Performance Dashboard")

# Create and display charts
chart_data = create_dashboard_charts()

col1, col2 = st.columns(2)

with col1:
    st.plotly_chart(chart_data['lead_scoring_trend'], use_container_width=True)
    st.plotly_chart(chart_data['sector_performance'], use_container_width=True)

with col2:
    st.plotly_chart(chart_data['campaign_roi'], use_container_width=True)
    st.plotly_chart(chart_data['ai_confidence_gauge'], use_container_width=True)

# AI Agent Status
st.markdown("### 🤖 Agentic AI Status")

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("**Lead Scoring Agent**")
    st.success("✅ Active - Processing 245 leads")
    st.markdown("Last action: Qualified 12 enterprise leads")

with col2:
    st.markdown("**Campaign Optimization Agent**")
    st.success("✅ Active - Monitoring 8 campaigns")
    st.markdown("Last action: Increased budget allocation +15%")

with col3:
    st.markdown("**Market Intelligence Agent**")
    st.success("✅ Active - Scanning 150+ sources")
    st.markdown("Last action: Detected emerging trend in fintech")

# Data Governance & Sovereign AI
st.markdown("### 🔒 Sovereign AI & Data Governance")

col1, col2 = st.columns(2)

with col1:
    st.markdown("**Data Residency Compliance**")
    st.success("✅ All data processed within US boundaries")
    st.success("✅ GDPR compliant data handling")
    st.success("✅ Industry-specific compliance verified")

with col2:
    st.markdown("**AI Governance Metrics**")
    st.info("🔍 Model Explainability: 94%")
    st.info("🛡️ Bias Detection: Active monitoring")
    st.info("📋 Audit Trail: 100% complete")

# Quick Actions
st.markdown("### ⚡ Quick Actions")

col1, col2, col3, col4 = st.columns(4)

with col1:
    if st.button("🎯 Score New Leads", use_container_width=True):
        st.success("AI agent activated for lead scoring")

with col2:
    if st.button("📊 Generate Report", use_container_width=True):
        st.success("Comprehensive report generation started")

with col3:
    if st.button("🔍 Analyze Competitors", use_container_width=True):
        st.success("Competitor analysis initiated")

with col4:
    if st.button("📝 Create Proposal", use_container_width=True):
        st.success("AI proposal generation started")

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #666;">
    <p>Powered by Deloitte AI Institute | Showcasing 2026 AI Priorities: Agentic AI, Physical AI, and Sovereign AI</p>
    <p>Real-time intelligence • Autonomous workflows • Compliant by design</p>
</div>
""", unsafe_allow_html=True)
