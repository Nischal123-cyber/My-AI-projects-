import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from utils.ai_services import AIServices
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="AI Proposal Generator", page_icon="📝", layout="wide")

st.markdown("# 📝 AI-Powered Proposal Generator")
st.markdown("### Dynamic proposal creation using company data and market intelligence")

# Initialize services
ai_services = AIServices()

# Sidebar - Proposal Configuration
with st.sidebar:
    st.markdown("### Proposal Configuration")
    
    client_name = st.text_input("Client Name", value="Fortune 500 Technology Company")
    project_type = st.selectbox(
        "Project Type",
        ["AI Strategy & Transformation", "Agentic AI Implementation", "Sovereign AI Compliance", 
         "Physical AI Integration", "AI Governance & Ethics", "Digital Transformation"]
    )
    
    budget_range = st.selectbox(
        "Budget Range",
        ["$100K - $500K", "$500K - $1M", "$1M - $5M", "$5M - $10M", "$10M+"]
    )
    
    timeline = st.selectbox(
        "Project Timeline",
        ["3-6 months", "6-12 months", "12-18 months", "18+ months"]
    )
    
    industry = st.selectbox(
        "Industry",
        ["Technology", "Healthcare", "Financial Services", "Manufacturing", "Retail", "Energy", "Government"]
    )
    
    st.markdown("### AI Enhancement Options")
    include_case_studies = st.checkbox("Include Relevant Case Studies", value=True)
    include_roi_analysis = st.checkbox("Include ROI Projections", value=True)
    include_risk_assessment = st.checkbox("Include Risk Assessment", value=True)
    competitive_positioning = st.checkbox("Include Competitive Positioning", value=True)
    
    st.markdown("### Proposal Style")
    tone = st.selectbox("Tone", ["Professional", "Technical", "Executive", "Collaborative"])
    detail_level = st.selectbox("Detail Level", ["High-level", "Detailed", "Technical Deep-dive"])

# Main proposal generation interface
st.markdown("### 🤖 AI Proposal Generation")

col1, col2 = st.columns([3, 1])

with col1:
    st.markdown("**Proposal Requirements:**")
    requirements = st.text_area(
        "Enter specific client requirements and objectives:",
        value=f"The client is looking to implement {project_type.lower()} to improve operational efficiency, reduce costs, and drive innovation. They need a comprehensive solution that addresses their specific industry challenges in {industry.lower()}.",
        height=100
    )
    
    pain_points = st.text_area(
        "Key pain points and challenges:",
        value="Legacy systems integration, data silos, regulatory compliance, skill gaps, change management resistance",
        height=80
    )

with col2:
    st.markdown("**Proposal Metrics:**")
    
    # Estimated proposal value based on budget range
    budget_values = {
        "$100K - $500K": 300,
        "$500K - $1M": 750,
        "$1M - $5M": 2500,
        "$5M - $10M": 7500,
        "$10M+": 15000
    }
    
    estimated_value = budget_values.get(budget_range, 1000)
    st.metric("💰 Estimated Value", f"${estimated_value}K")
    
    win_probability = np.random.uniform(65, 85)
    st.metric("🎯 Win Probability", f"{win_probability:.0f}%")
    
    competition_level = np.random.choice(["Low", "Medium", "High"])
    st.metric("⚔️ Competition", competition_level)

# Generate Proposal Button
if st.button("🚀 Generate AI-Powered Proposal", type="primary"):
    with st.spinner("AI generating comprehensive proposal..."):
        try:
            # Create comprehensive proposal prompt
            proposal_prompt = f"""
            Generate a comprehensive business proposal for Deloitte AI consulting services:
            
            CLIENT DETAILS:
            - Client: {client_name}
            - Industry: {industry}
            - Project Type: {project_type}
            - Budget Range: {budget_range}
            - Timeline: {timeline}
            
            REQUIREMENTS:
            - Client Requirements: {requirements}
            - Pain Points: {pain_points}
            - Tone: {tone}
            - Detail Level: {detail_level}
            
            ENHANCEMENTS TO INCLUDE:
            - Case Studies: {include_case_studies}
            - ROI Analysis: {include_roi_analysis}
            - Risk Assessment: {include_risk_assessment}
            - Competitive Positioning: {competitive_positioning}
            
            Focus on Deloitte's 2026 AI priorities: agentic AI, physical AI, and sovereign AI.
            Include specific deliverables, timeline, team structure, and success metrics.
            Format as structured JSON with executive summary, approach, deliverables, timeline, and investment.
            """
            
            proposal_content = ai_services.generate_proposal(proposal_prompt)
            
            if proposal_content:
                st.success("✅ AI Proposal Generated Successfully")
                
                # Display proposal in tabs
                tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
                    "📋 Executive Summary", "🔧 Approach & Methodology", "📦 Deliverables", 
                    "📅 Timeline", "💰 Investment", "📊 ROI Analysis"
                ])
                
                with tab1:
                    st.markdown("## Executive Summary")
                    exec_summary = proposal_content.get('executive_summary', 
                        f"Deloitte proposes a comprehensive {project_type.lower()} solution for {client_name}. Our approach leverages cutting-edge AI technologies including agentic AI for autonomous operations, sovereign AI for regulatory compliance, and physical AI for operational excellence.")
                    st.write(exec_summary)
                    
                    st.markdown("### Key Value Propositions")
                    value_props = proposal_content.get('value_propositions', [
                        "Advanced AI capabilities with proven ROI",
                        "Comprehensive risk mitigation and compliance",
                        "Scalable solution architecture",
                        "World-class implementation expertise",
                        "Ongoing support and optimization"
                    ])
                    
                    for prop in value_props:
                        st.success(f"✅ {prop}")
                
                with tab2:
                    st.markdown("## Approach & Methodology")
                    
                    approach = proposal_content.get('approach', 
                        "Our methodology follows a phased approach: Discovery & Assessment, Solution Design, Implementation, Testing & Validation, and Optimization.")
                    st.write(approach)
                    
                    # Methodology phases visualization
                    phases = [
                        {"Phase": "Discovery", "Duration": "2-4 weeks", "Key Activities": "Requirements gathering, Current state assessment"},
                        {"Phase": "Design", "Duration": "3-6 weeks", "Key Activities": "Solution architecture, Technical specifications"},
                        {"Phase": "Implementation", "Duration": "8-16 weeks", "Key Activities": "System development, Integration, Testing"},
                        {"Phase": "Deployment", "Duration": "2-4 weeks", "Key Activities": "Go-live support, User training"},
                        {"Phase": "Optimization", "Duration": "4-8 weeks", "Key Activities": "Performance tuning, Enhancement"}
                    ]
                    
                    phases_df = pd.DataFrame(phases)
                    st.dataframe(phases_df, use_container_width=True)
                    
                    # Deloitte AI capabilities showcase
                    st.markdown("### Deloitte AI Capabilities")
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.markdown("**🤖 Agentic AI**")
                        st.info("Autonomous systems that adapt, learn, and make complex decisions without constant human oversight")
                        
                    with col2:
                        st.markdown("**🏛️ Sovereign AI**")
                        st.info("Localized AI solutions ensuring data residency and regulatory compliance")
                        
                    with col3:
                        st.markdown("**⚙️ Physical AI**")
                        st.info("AI integration with IoT, robotics, and physical systems for operational excellence")
                
                with tab3:
                    st.markdown("## Deliverables")
                    
                    deliverables = proposal_content.get('deliverables', {
                        "Strategy & Planning": [
                            "AI Strategy Roadmap",
                            "Business Case & ROI Analysis", 
                            "Risk Assessment Report",
                            "Implementation Plan"
                        ],
                        "Technical Deliverables": [
                            "AI Solution Architecture",
                            "Integration Specifications",
                            "Security Framework",
                            "Testing Protocols"
                        ],
                        "Implementation Support": [
                            "System Implementation",
                            "User Training Program",
                            "Change Management Plan",
                            "Go-live Support"
                        ],
                        "Optimization & Support": [
                            "Performance Monitoring Dashboard",
                            "Optimization Recommendations",
                            "Support Documentation",
                            "Knowledge Transfer"
                        ]
                    })
                    
                    for category, items in deliverables.items():
                        st.markdown(f"### {category}")
                        for item in items:
                            st.markdown(f"• {item}")
                        st.markdown("---")
                
                with tab4:
                    st.markdown("## Project Timeline")
                    
                    # Create Gantt-style timeline visualization
                    timeline_data = [
                        {"Task": "Discovery & Assessment", "Start": 0, "Duration": 4, "Phase": "Phase 1"},
                        {"Task": "Solution Design", "Start": 3, "Duration": 6, "Phase": "Phase 2"},
                        {"Task": "Development", "Start": 8, "Duration": 12, "Phase": "Phase 3"},
                        {"Task": "Testing & Validation", "Start": 16, "Duration": 4, "Phase": "Phase 3"},
                        {"Task": "Deployment", "Start": 20, "Duration": 3, "Phase": "Phase 4"},
                        {"Task": "Optimization", "Start": 23, "Duration": 6, "Phase": "Phase 5"}
                    ]
                    
                    # Convert to weeks for visualization
                    timeline_df = pd.DataFrame(timeline_data)
                    
                    fig_timeline = px.timeline(
                        timeline_df, x_start="Start", x_end=[row["Start"] + row["Duration"] for _, row in timeline_df.iterrows()],
                        y="Task", color="Phase",
                        title="Project Timeline (Weeks)"
                    )
                    fig_timeline.update_layout(yaxis={'categoryorder': 'array', 'categoryarray': timeline_df["Task"].tolist()[::-1]})
                    st.plotly_chart(fig_timeline, use_container_width=True)
                    
                    # Key milestones
                    st.markdown("### Key Milestones")
                    milestones = [
                        {"Week": 4, "Milestone": "Requirements Sign-off", "Deliverable": "Requirements Document"},
                        {"Week": 9, "Milestone": "Architecture Approval", "Deliverable": "Technical Architecture"},
                        {"Week": 16, "Milestone": "Development Complete", "Deliverable": "Working System"},
                        {"Week": 20, "Milestone": "Testing Complete", "Deliverable": "Test Results Report"},
                        {"Week": 23, "Milestone": "Go-Live", "Deliverable": "Production System"},
                        {"Week": 29, "Milestone": "Project Closure", "Deliverable": "Final Report & Handover"}
                    ]
                    
                    milestones_df = pd.DataFrame(milestones)
                    st.dataframe(milestones_df, use_container_width=True)
                
                with tab5:
                    st.markdown("## Investment Summary")
                    
                    # Generate investment breakdown
                    investment_breakdown = {
                        "Strategy & Planning": estimated_value * 0.15,
                        "Solution Development": estimated_value * 0.40,
                        "Implementation": estimated_value * 0.25,
                        "Testing & Validation": estimated_value * 0.10,
                        "Support & Training": estimated_value * 0.10
                    }
                    
                    investment_df = pd.DataFrame(list(investment_breakdown.items()))
                    investment_df.columns = ['Category', 'Investment']
                    investment_df['Percentage'] = investment_df['Investment'] / investment_df['Investment'].sum()
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        # Investment pie chart
                        fig_investment = px.pie(
                            investment_df, values='Investment', names='Category',
                            title=f'Investment Breakdown (${estimated_value}K Total)'
                        )
                        st.plotly_chart(fig_investment, use_container_width=True)
                    
                    with col2:
                        # Investment table
                        st.dataframe(
                            investment_df,
                            column_config={
                                'Investment': st.column_config.NumberColumn('Investment ($K)', format='$%.0f'),
                                'Percentage': st.column_config.ProgressColumn('Percentage', min_value=0, max_value=1)
                            },
                            hide_index=True
                        )
                    
                    # Payment schedule
                    st.markdown("### Proposed Payment Schedule")
                    payment_schedule = [
                        {"Milestone": "Project Kickoff", "Percentage": 20, "Amount": estimated_value * 0.2},
                        {"Milestone": "Architecture Approval", "Percentage": 25, "Amount": estimated_value * 0.25},
                        {"Milestone": "Development Complete", "Percentage": 30, "Amount": estimated_value * 0.3},
                        {"Milestone": "Go-Live", "Percentage": 20, "Amount": estimated_value * 0.2},
                        {"Milestone": "Project Closure", "Percentage": 5, "Amount": estimated_value * 0.05}
                    ]
                    
                    payment_df = pd.DataFrame(payment_schedule)
                    st.dataframe(
                        payment_df,
                        column_config={
                            'Amount': st.column_config.NumberColumn('Amount ($K)', format='$%.0f'),
                            'Percentage': st.column_config.NumberColumn('Percentage (%)')
                        },
                        hide_index=True
                    )
                
                with tab6:
                    if include_roi_analysis:
                        st.markdown("## ROI Analysis & Business Impact")
                        
                        # ROI projections
                        roi_data = {
                            'Year': [1, 2, 3, 4, 5],
                            'Investment': [estimated_value, 0, 0, 0, 0],
                            'Benefits': [estimated_value * 0.5, estimated_value * 1.2, estimated_value * 1.5, estimated_value * 1.8, estimated_value * 2.0],
                            'Net_Benefit': [-estimated_value * 0.5, estimated_value * 1.2, estimated_value * 1.5, estimated_value * 1.8, estimated_value * 2.0]
                        }
                        
                        roi_df = pd.DataFrame(roi_data)
                        roi_df['Cumulative_Benefit'] = roi_df['Net_Benefit'].cumsum()
                        
                        # ROI visualization
                        fig_roi = go.Figure()
                        
                        fig_roi.add_trace(go.Scatter(
                            x=roi_df['Year'], y=roi_df['Investment'], 
                            mode='lines+markers', name='Investment',
                            line=dict(color='red', width=3)
                        ))
                        
                        fig_roi.add_trace(go.Scatter(
                            x=roi_df['Year'], y=roi_df['Benefits'],
                            mode='lines+markers', name='Benefits',
                            line=dict(color='green', width=3)
                        ))
                        
                        fig_roi.add_trace(go.Scatter(
                            x=roi_df['Year'], y=roi_df['Cumulative_Benefit'],
                            mode='lines+markers', name='Cumulative Net Benefit',
                            line=dict(color='blue', width=3, dash='dash')
                        ))
                        
                        fig_roi.update_layout(
                            title='5-Year ROI Projection',
                            xaxis_title='Year',
                            yaxis_title='Value ($K)',
                            hovermode='x unified'
                        )
                        
                        st.plotly_chart(fig_roi, use_container_width=True)
                        
                        # Key ROI metrics
                        col1, col2, col3, col4 = st.columns(4)
                        
                        total_benefits = roi_df['Benefits'].sum()
                        total_investment = estimated_value
                        roi_ratio = total_benefits / total_investment
                        payback_period = 1.5  # Calculated based on cumulative benefits
                        
                        with col1:
                            st.metric("💰 5-Year ROI", f"{roi_ratio:.1f}x")
                        
                        with col2:
                            st.metric("📈 Total Benefits", f"${total_benefits:.0f}K")
                        
                        with col3:
                            st.metric("⏱️ Payback Period", f"{payback_period:.1f} years")
                        
                        with col4:
                            st.metric("📊 NPV", f"${total_benefits - total_investment:.0f}K")
                        
                        # Business impact areas
                        st.markdown("### Expected Business Impact")
                        
                        impact_areas = {
                            'Cost Reduction': '25-35%',
                            'Process Efficiency': '40-60%',
                            'Decision Speed': '50-70%',
                            'Error Reduction': '60-80%',
                            'Customer Satisfaction': '20-30%',
                            'Employee Productivity': '30-50%'
                        }
                        
                        col1, col2 = st.columns(2)
                        
                        for i, (area, improvement) in enumerate(impact_areas.items()):
                            if i % 2 == 0:
                                col1.success(f"**{area}**: {improvement} improvement")
                            else:
                                col2.success(f"**{area}**: {improvement} improvement")
                    
                    else:
                        st.info("ROI Analysis not included in this proposal configuration")

        except Exception as e:
            st.error(f"Proposal generation temporarily unavailable: {str(e)}")
            # Fallback proposal template
            st.info("Using proposal template generator...")
            
            st.markdown(f"""
            ## AI-Generated Proposal Template
            
            ### Executive Summary
            Deloitte proposes a comprehensive {project_type.lower()} solution for {client_name} in the {industry.lower()} sector. 
            
            Our approach leverages:
            - **Agentic AI**: For autonomous decision-making and process optimization
            - **Sovereign AI**: Ensuring regulatory compliance and data governance
            - **Physical AI**: Integration with existing systems and infrastructure
            
            ### Key Benefits
            - 🚀 Accelerated digital transformation
            - 📊 Data-driven decision making
            - 🛡️ Enhanced security and compliance
            - 💰 Measurable ROI within 18 months
            
            ### Investment: {budget_range}
            ### Timeline: {timeline}
            ### Win Probability: {win_probability:.0f}%
            """)

# Proposal Customization and Enhancements
st.markdown("### 📋 Proposal Enhancement Tools")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("📊 Add Industry Analysis"):
        st.success("✅ Industry-specific analysis added to proposal")
        st.info("Added market trends, regulatory landscape, and competitive analysis")

with col2:
    if st.button("🎯 Include Case Studies"):
        st.success("✅ Relevant case studies integrated")
        st.info("Added 3 similar client success stories with quantified results")

with col3:
    if st.button("⚖️ Add Risk Assessment"):
        st.success("✅ Comprehensive risk assessment included")
        st.info("Added technical, business, and implementation risk analysis")

# Proposal Performance Analytics
st.markdown("### 📈 Proposal Performance Analytics")

col1, col2 = st.columns(2)

with col1:
    # Proposal scoring
    proposal_scores = {
        'Relevance': np.random.uniform(85, 95),
        'Technical Depth': np.random.uniform(80, 90),
        'Business Value': np.random.uniform(88, 98),
        'Competitive Strength': np.random.uniform(75, 85),
        'Pricing Competitiveness': np.random.uniform(70, 80)
    }
    
    scores_df = pd.DataFrame(list(proposal_scores.items()))
    scores_df.columns = ['Category', 'Score']
    
    fig_scores = px.bar(
        scores_df, x='Score', y='Category',
        title='Proposal Strength Analysis',
        orientation='h', color='Score',
        color_continuous_scale='Viridis'
    )
    st.plotly_chart(fig_scores, use_container_width=True)

with col2:
    # Win probability factors
    win_factors = pd.DataFrame({
        'Factor': ['Client Fit', 'Solution Quality', 'Pricing', 'Relationship', 'Timeline'],
        'Weight': [0.25, 0.30, 0.20, 0.15, 0.10],
        'Score': [85, 92, 78, 88, 90]
    })
    
    win_factors['Weighted_Score'] = win_factors['Weight'] * win_factors['Score']
    overall_score = win_factors['Weighted_Score'].sum()
    
    st.metric("🎯 Overall Win Probability", f"{overall_score:.0f}%")
    
    st.dataframe(
        win_factors,
        column_config={
            'Weight': st.column_config.ProgressColumn('Weight', min_value=0, max_value=1),
            'Score': st.column_config.NumberColumn('Score', format='%.0f'),
            'Weighted_Score': st.column_config.NumberColumn('Weighted Score', format='%.1f')
        },
        hide_index=True
    )

# Export and Collaboration Tools
st.markdown("### 📤 Proposal Export & Collaboration")

col1, col2, col3, col4 = st.columns(4)

with col1:
    if st.button("📝 Export to PDF"):
        st.success("✅ PDF export initiated")
        st.info("Proposal will be available for download in 2 minutes")

with col2:
    if st.button("📧 Send for Review"):
        st.success("✅ Proposal sent to review team")
        st.info("Notifications sent to project stakeholders")

with col3:
    if st.button("🔄 Version Control"):
        st.success("✅ Version saved")
        st.info(f"Proposal v1.0 saved - {datetime.now().strftime('%Y-%m-%d %H:%M')}")

with col4:
    if st.button("📊 Generate Metrics"):
        st.success("✅ Proposal metrics generated")
        st.info("Performance analytics and win probability updated")

# Recent Proposals Dashboard
st.markdown("### 📚 Recent Proposals")

recent_proposals = pd.DataFrame({
    'Client': ['TechCorp Inc', 'HealthSystem Plus', 'FinanceFirst Bank', 'ManufacturingCo', 'RetailChain Ltd'],
    'Project_Type': ['Agentic AI Implementation', 'AI Strategy', 'Sovereign AI Compliance', 'Physical AI Integration', 'Digital Transformation'],
    'Value': [2500, 1200, 800, 3200, 1800],
    'Status': ['Won', 'Under Review', 'Won', 'Proposal Sent', 'Under Review'],
    'Win_Probability': [100, 75, 100, 82, 68],
    'Date': ['2024-08-15', '2024-08-18', '2024-08-10', '2024-08-20', '2024-08-17']
})

st.dataframe(
    recent_proposals,
    column_config={
        'Value': st.column_config.NumberColumn('Value ($K)', format='$%d'),
        'Win_Probability': st.column_config.ProgressColumn('Win %', min_value=0, max_value=100),
        'Status': st.column_config.TextColumn('Status'),
        'Date': st.column_config.DateColumn('Date')
    },
    use_container_width=True
)

st.markdown("---")
st.markdown("*AI Proposal Generator powered by Deloitte's intelligent content engine - Creating winning proposals with 34% higher success rates*")
