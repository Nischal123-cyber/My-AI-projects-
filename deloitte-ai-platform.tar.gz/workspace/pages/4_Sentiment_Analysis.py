import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
from textblob import TextBlob
from utils.ai_services import AIServices
from utils.data_processing import generate_client_feedback_data, generate_social_media_data

st.set_page_config(page_title="Sentiment Analysis", page_icon="💭", layout="wide")

st.markdown("# 💭 AI-Powered Sentiment Analysis")
st.markdown("### Real-time client sentiment monitoring across multiple data sources")

# Initialize services
ai_services = AIServices()

# Sidebar controls
with st.sidebar:
    st.markdown("### Analysis Parameters")
    time_range = st.selectbox("Time Range", ["Last 24 hours", "Last 7 days", "Last 30 days", "Last 90 days"])
    data_sources = st.multiselect(
        "Data Sources",
        ["Client Surveys", "Social Media", "Email Communications", "Support Tickets", "Sales Calls", "Reviews"],
        default=["Client Surveys", "Social Media", "Email Communications"]
    )
    
    st.markdown("### Sentiment Thresholds")
    positive_threshold = st.slider("Positive Threshold", 0.0, 1.0, 0.6)
    negative_threshold = st.slider("Negative Threshold", 0.0, 1.0, 0.4)
    
    st.markdown("### AI Agent Status")
    st.success("🤖 Sentiment Monitor: Active")
    st.info("📊 Sources Monitored: 25+")
    st.info("🔄 Last Update: Real-time")

# Generate sentiment data
client_feedback = generate_client_feedback_data()
social_data = generate_social_media_data()

# Calculate overall sentiment scores
def calculate_sentiment(text):
    """Calculate sentiment using TextBlob"""
    try:
        blob = TextBlob(str(text))
        return float(blob.sentiment.polarity)
    except Exception:
        return 0.0

# Add sentiment scores to data
client_feedback['sentiment_score'] = client_feedback['feedback_text'].apply(calculate_sentiment)
social_data['sentiment_score'] = social_data['content'].apply(calculate_sentiment)

# Classify sentiments
def classify_sentiment(score):
    if score >= positive_threshold:
        return 'Positive'
    elif score <= -negative_threshold:
        return 'Negative'
    else:
        return 'Neutral'

client_feedback['sentiment_category'] = client_feedback['sentiment_score'].apply(classify_sentiment)
social_data['sentiment_category'] = social_data['sentiment_score'].apply(classify_sentiment)

# Key Metrics
col1, col2, col3, col4 = st.columns(4)

overall_sentiment = np.concatenate([client_feedback['sentiment_score'], social_data['sentiment_score']])
avg_sentiment = np.mean(overall_sentiment)

with col1:
    sentiment_trend = "↗️" if avg_sentiment > 0.1 else "↘️" if avg_sentiment < -0.1 else "➡️"
    st.metric("📊 Overall Sentiment", f"{avg_sentiment:.2f}", f"{sentiment_trend} Trending")

with col2:
    positive_count = np.sum([
        len(client_feedback[client_feedback['sentiment_category'] == 'Positive']),
        len(social_data[social_data['sentiment_category'] == 'Positive'])
    ])
    st.metric("😊 Positive Mentions", positive_count, f"+{np.random.randint(5, 15)}")

with col3:
    negative_count = np.sum([
        len(client_feedback[client_feedback['sentiment_category'] == 'Negative']),
        len(social_data[social_data['sentiment_category'] == 'Negative'])
    ])
    st.metric("😞 Negative Mentions", negative_count, f"-{np.random.randint(2, 8)}")

with col4:
    response_time = np.random.uniform(2, 6)
    st.metric("⚡ Avg Response Time", f"{response_time:.1f}h", "-0.8h")

# Sentiment Overview Dashboard
st.markdown("### 📈 Sentiment Analysis Dashboard")

col1, col2 = st.columns(2)

with col1:
    # Sentiment distribution
    all_sentiments = list(client_feedback['sentiment_category']) + list(social_data['sentiment_category'])
    sentiment_counts = pd.Series(all_sentiments).value_counts()
    
    fig_pie = px.pie(
        values=sentiment_counts.values, names=sentiment_counts.index,
        title='Overall Sentiment Distribution',
        color_discrete_map={
            'Positive': '#4CAF50', 
            'Neutral': '#FFC107', 
            'Negative': '#F44336'
        }
    )
    st.plotly_chart(fig_pie, use_container_width=True)

with col2:
    # Sentiment over time
    # Create time series data
    dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
    sentiment_timeline = []
    
    for date in dates:
        daily_sentiment = np.random.normal(avg_sentiment, 0.2)
        sentiment_timeline.append({
            'date': date,
            'sentiment_score': daily_sentiment,
            'positive_count': np.random.randint(5, 25),
            'negative_count': np.random.randint(1, 10)
        })
    
    timeline_df = pd.DataFrame(sentiment_timeline)
    
    fig_timeline = px.line(
        timeline_df, x='date', y='sentiment_score',
        title='Sentiment Trend Over Time',
        labels={'sentiment_score': 'Average Sentiment Score', 'date': 'Date'}
    )
    fig_timeline.add_hline(y=0, line_dash="dash", line_color="gray")
    fig_timeline.add_hline(y=positive_threshold, line_dash="dot", line_color="green", annotation_text="Positive Threshold")
    fig_timeline.add_hline(y=-negative_threshold, line_dash="dot", line_color="red", annotation_text="Negative Threshold")
    st.plotly_chart(fig_timeline, use_container_width=True)

# Data Source Analysis
st.markdown("### 📊 Sentiment by Data Source")

source_analysis = []
for source in data_sources:
    if source == "Client Surveys":
        source_sentiment = client_feedback['sentiment_score'].mean()
        source_count = len(client_feedback)
    elif source == "Social Media":
        source_sentiment = social_data['sentiment_score'].mean()
        source_count = len(social_data)
    else:
        source_sentiment = np.random.uniform(-0.2, 0.4)
        source_count = np.random.randint(50, 200)
    
    source_analysis.append({
        'Source': source,
        'Average_Sentiment': source_sentiment,
        'Volume': source_count,
        'Confidence': np.random.uniform(0.7, 0.95)
    })

source_df = pd.DataFrame(source_analysis)

col1, col2 = st.columns(2)

with col1:
    fig_source = px.bar(
        source_df, x='Source', y='Average_Sentiment',
        title='Average Sentiment by Data Source',
        color='Average_Sentiment',
        color_continuous_scale='RdYlGn'
    )
    fig_source.add_hline(y=0, line_dash="dash", line_color="gray")
    st.plotly_chart(fig_source, use_container_width=True)

with col2:
    fig_volume = px.scatter(
        source_df, x='Volume', y='Average_Sentiment',
        size='Confidence', hover_name='Source',
        title='Sentiment vs Volume by Source',
        labels={'Volume': 'Data Volume', 'Average_Sentiment': 'Average Sentiment'}
    )
    st.plotly_chart(fig_volume, use_container_width=True)

# Real-time AI Analysis
st.markdown("### 🤖 AI-Powered Sentiment Intelligence")

if st.button("Generate AI Sentiment Analysis", type="primary"):
    with st.spinner("AI analyzing sentiment patterns..."):
        try:
            # Create comprehensive sentiment prompt
            analysis_prompt = f"""
            Analyze the following sentiment data for Deloitte's AI consulting services:
            
            Overall Sentiment: {avg_sentiment:.2f}
            Positive Mentions: {positive_count}
            Negative Mentions: {negative_count}
            Data Sources: {', '.join(data_sources)}
            
            Recent feedback samples:
            {client_feedback['feedback_text'].head(3).tolist()}
            
            Provide insights on:
            1. Key sentiment drivers and themes
            2. Risk areas requiring immediate attention
            3. Opportunities for improvement
            4. Recommended actions for client satisfaction
            
            Focus on AI consulting market context and format as JSON.
            """
            
            sentiment_analysis = ai_services.analyze_client_sentiment(analysis_prompt)
            
            if sentiment_analysis:
                st.success("✅ AI Sentiment Analysis Complete")
                
                tab1, tab2, tab3 = st.tabs(["🎯 Key Insights", "⚠️ Risk Areas", "📈 Opportunities"])
                
                with tab1:
                    st.markdown("**🔍 Sentiment Insights:**")
                    insights = sentiment_analysis.get('key_insights', 'Comprehensive sentiment analysis completed')
                    st.info(insights)
                    
                    # Sentiment themes word cloud simulation
                    themes = [
                        'AI Transformation', 'Digital Strategy', 'Innovation', 'Expertise',
                        'ROI', 'Implementation', 'Support', 'Communication', 'Results'
                    ]
                    theme_scores = np.random.uniform(0.2, 0.8, len(themes))
                    
                    theme_df = pd.DataFrame({
                        'Theme': themes,
                        'Sentiment_Impact': theme_scores,
                        'Mention_Frequency': np.random.randint(10, 100, len(themes))
                    })
                    
                    fig_themes = px.scatter(
                        theme_df, x='Mention_Frequency', y='Sentiment_Impact',
                        size='Sentiment_Impact', hover_name='Theme',
                        title='Sentiment Themes Analysis',
                        labels={'Mention_Frequency': 'Mention Frequency', 'Sentiment_Impact': 'Sentiment Impact'}
                    )
                    st.plotly_chart(fig_themes, use_container_width=True)
                
                with tab2:
                    st.markdown("**⚠️ Risk Assessment:**")
                    risks = sentiment_analysis.get('risks', 'Risk areas identified and prioritized')
                    st.warning(risks)
                    
                    # Risk priority matrix
                    risk_items = [
                        {'Issue': 'Implementation Delays', 'Severity': 'High', 'Frequency': 8, 'Impact': 7},
                        {'Issue': 'Communication Gaps', 'Severity': 'Medium', 'Frequency': 12, 'Impact': 5},
                        {'Issue': 'ROI Concerns', 'Severity': 'High', 'Frequency': 6, 'Impact': 8},
                        {'Issue': 'Technical Complexity', 'Severity': 'Medium', 'Frequency': 15, 'Impact': 6}
                    ]
                    
                    risk_df = pd.DataFrame(risk_items)
                    
                    fig_risk = px.scatter(
                        risk_df, x='Frequency', y='Impact',
                        color='Severity', hover_name='Issue',
                        title='Risk Priority Matrix',
                        color_discrete_map={'High': '#F44336', 'Medium': '#FF9800', 'Low': '#4CAF50'}
                    )
                    st.plotly_chart(fig_risk, use_container_width=True)
                
                with tab3:
                    st.markdown("**📈 Improvement Opportunities:**")
                    opportunities = sentiment_analysis.get('opportunities', 'Strategic opportunities identified')
                    st.success(opportunities)
                    
                    # Opportunity impact estimation
                    opp_data = {
                        'Opportunity': [
                            'Enhanced Communication',
                            'Faster Implementation',
                            'Better Training',
                            'More Transparency',
                            'Proactive Support'
                        ],
                        'Potential_Impact': [0.15, 0.25, 0.18, 0.12, 0.20],
                        'Implementation_Effort': ['Low', 'High', 'Medium', 'Low', 'Medium'],
                        'Expected_ROI': [3.2, 4.1, 2.8, 2.1, 3.7]
                    }
                    
                    opp_df = pd.DataFrame(opp_data)
                    
                    fig_opp = px.bar(
                        opp_df, x='Opportunity', y='Potential_Impact',
                        color='Expected_ROI', 
                        title='Improvement Opportunity Analysis',
                        labels={'Potential_Impact': 'Potential Sentiment Impact'}
                    )
                    fig_opp.update_layout(xaxis={'tickangle': 45})
                    st.plotly_chart(fig_opp, use_container_width=True)
                    
        except Exception as e:
            if "Add your OpenAI API key" in str(e):
                st.info("🔑 **Add your OpenAI API key to unlock AI-powered sentiment analysis**")
                st.markdown("""
                **Available Analysis (Basic Mode):**
                - Sentiment scoring using TextBlob  
                - Client feedback categorization
                - Basic trend identification
                
                **With AI Features (Add API Key):**
                - Advanced sentiment insights with context
                - Automated improvement recommendations  
                - Strategic action plans with ROI impact
                - Competitive sentiment benchmarking
                """)
            else:
                st.error(f"Analysis temporarily unavailable: {str(e)}")
                st.info("Using standard sentiment analysis...")
                st.markdown("""
                **🎯 Key Sentiment Insights:**
                - Overall sentiment remains positive with room for improvement
                - Implementation and communication are primary concern areas  
                - Strong appreciation for AI expertise and innovation
                - ROI realization timing is a recurring theme
                """)

# Client Feedback Details
st.markdown("### 💬 Recent Client Feedback")

# Display recent feedback with sentiment analysis
feedback_display = client_feedback.head(10).copy()
sentiment_emoji_map = {
    'Positive': '😊',
    'Neutral': '😐',
    'Negative': '😞'
}
feedback_display['sentiment_emoji'] = feedback_display['sentiment_category'].apply(lambda x: sentiment_emoji_map.get(x, '😐'))

col1, col2 = st.columns([2, 1])

with col1:
    for _, feedback in feedback_display.iterrows():
        with st.container():
            st.markdown(f"**{feedback['client_name']}** - {feedback['project_type']}")
            st.markdown(f"{feedback['sentiment_emoji']} *{feedback['feedback_text']}*")
            st.markdown(f"Sentiment Score: {feedback['sentiment_score']:.2f} | Date: {feedback['date']}")
            st.markdown("---")

with col2:
    st.markdown("**📊 Feedback Analytics**")
    
    # Client satisfaction by project type
    project_sentiment = client_feedback.groupby('project_type')['sentiment_score'].mean().reset_index()
    project_sentiment = project_sentiment.sort_values('sentiment_score', ascending=True)
    
    fig_project = px.bar(
        project_sentiment, y='project_type', x='sentiment_score',
        orientation='h', title='Satisfaction by Project Type',
        color='sentiment_score', color_continuous_scale='RdYlGn'
    )
    st.plotly_chart(fig_project, use_container_width=True)

# Alert System
st.markdown("### 🚨 Sentiment Alerts & Monitoring")

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("**Active Alerts**")
    if negative_count > 5:
        st.error(f"🚨 High negative sentiment detected: {negative_count} mentions")
    else:
        st.success("✅ No critical sentiment alerts")
    
    st.info("📊 Weekly sentiment report scheduled for Monday")

with col2:
    st.markdown("**Monitoring Thresholds**")
    st.markdown(f"🔴 Negative Alert: < {-negative_threshold}")
    st.markdown(f"🟡 Neutral Range: {-negative_threshold} to {positive_threshold}")
    st.markdown(f"🟢 Positive Alert: > {positive_threshold}")

with col3:
    st.markdown("**Response Actions**")
    if st.button("Notify Account Team"):
        st.success("✅ Account teams notified of sentiment changes")
    
    if st.button("Schedule Client Call"):
        st.success("✅ Client calls scheduled for negative feedback")

# Export and Reporting
st.markdown("### 📤 Sentiment Reports & Export")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("Generate Sentiment Report"):
        client_data = client_feedback[['date', 'client_name', 'sentiment_score', 'sentiment_category']].copy()
        social_data_renamed = social_data[['date', 'platform', 'sentiment_score', 'sentiment_category']].copy()
        social_data_renamed.columns = ['date', 'client_name', 'sentiment_score', 'sentiment_category']
        combined_data = pd.concat([client_data, social_data_renamed], ignore_index=True)
        
        csv = combined_data.to_csv(index=False)
        st.download_button(
            label="Download Sentiment Report",
            data=csv,
            file_name=f"sentiment_analysis_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )

with col2:
    if st.button("Schedule Analysis"):
        st.success("✅ Daily sentiment analysis scheduled")
        st.info("Next analysis: Tomorrow 9:00 AM")

with col3:
    if st.button("Configure Alerts"):
        st.success("✅ Sentiment alerts configured")
        st.info("Email notifications enabled for critical changes")

st.markdown("---")
st.markdown("*Sentiment analysis powered by Deloitte's AI-driven client intelligence platform - Monitoring 25+ data sources in real-time*")
