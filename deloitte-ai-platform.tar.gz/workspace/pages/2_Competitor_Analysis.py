import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
from utils.ai_services import AIServices
from utils.data_processing import generate_competitor_data
import requests

st.set_page_config(page_title="Competitor Analysis", page_icon="🔍", layout="wide")

st.markdown("# 🔍 AI-Powered Competitor Analysis")
st.markdown("### Autonomous market intelligence and competitive positioning")

# Initialize services
ai_services = AIServices()

# Sidebar controls
with st.sidebar:
    st.markdown("### Analysis Parameters")
    analysis_depth = st.selectbox("Analysis Depth", ["Surface", "Standard", "Deep"])
    time_frame = st.selectbox("Time Frame", ["Last 30 days", "Last 90 days", "Last 6 months"])
    
    st.markdown("### Competitor Focus")
    competitor_types = st.multiselect(
        "Competitor Types",
        ["Big 4 Consulting", "Tech Giants", "Specialized AI Firms", "Regional Players"],
        default=["Big 4 Consulting", "Tech Giants"]
    )
    
    st.markdown("### AI Agent Status")
    st.success("🤖 Market Intelligence Agent: Active")
    st.info("📊 Data Sources: 150+ monitored")
    st.info("🔄 Last Update: 2 minutes ago")

# Generate competitor data
competitors_df = generate_competitor_data()

# Key Metrics
col1, col2, col3, col4 = st.columns(4)

with col1:
    market_share = np.random.uniform(15, 25)
    st.metric("🏆 Market Position", "#2", "↑1 position")

with col2:
    competitive_strength = np.random.uniform(75, 85)
    st.metric("💪 Competitive Strength", f"{competitive_strength:.1f}%", "+2.1%")

with col3:
    threat_level = np.random.choice(["Low", "Medium", "High"])
    st.metric("⚠️ Threat Level", threat_level, "No change")

with col4:
    opportunities = np.random.randint(3, 8)
    st.metric("🎯 New Opportunities", opportunities, f"+{np.random.randint(1, 3)}")

# Competitive Landscape Overview
st.markdown("### 🗺️ Competitive Landscape")

col1, col2 = st.columns(2)

with col1:
    # Market positioning bubble chart
    fig_positioning = px.scatter(
        competitors_df, x='market_share', y='ai_capability_score',
        size='revenue_millions', color='threat_level',
        hover_name='company_name',
        title='Competitive Positioning Map',
        labels={'market_share': 'Market Share (%)', 'ai_capability_score': 'AI Capability Score'},
        color_discrete_map={'High': '#FF6B6B', 'Medium': '#FFE66D', 'Low': '#4ECDC4'}
    )
    fig_positioning.add_annotation(
        x=22, y=85, text="Deloitte Position",
        showarrow=True, arrowhead=2, arrowcolor="green"
    )
    st.plotly_chart(fig_positioning, use_container_width=True)

with col2:
    # AI capability comparison
    ai_comparison = competitors_df.sort_values('ai_capability_score', ascending=True)
    fig_ai = px.bar(
        ai_comparison, x='ai_capability_score', y='company_name',
        orientation='h', title='AI Capability Comparison',
        color='ai_capability_score', color_continuous_scale='Viridis'
    )
    st.plotly_chart(fig_ai, use_container_width=True)

# Service Offerings Analysis
st.markdown("### 🛠️ Service Offerings Comparison")

# Create service offerings data
services = ['AI Strategy', 'Data Analytics', 'Digital Transformation', 'Cloud Migration', 'Automation']
service_data = []

for _, competitor in competitors_df.iterrows():
    for service in services:
        service_data.append({
            'Company': competitor['company_name'],
            'Service': service,
            'Strength': np.random.randint(1, 6)  # 1-5 scale
        })

service_df = pd.DataFrame(service_data)

# Create heatmap
fig_heatmap = px.density_heatmap(
    service_df, x='Service', y='Company', z='Strength',
    title='Service Offering Strength Heatmap',
    color_continuous_scale='RdYlGn'
)
st.plotly_chart(fig_heatmap, use_container_width=True)

# Recent Competitor Activities
st.markdown("### 📰 Recent Competitor Activities")

col1, col2 = st.columns(2)

with col1:
    st.markdown("**🚨 Critical Updates**")
    
    activities = [
        "McKinsey announced new AI partnership with Microsoft",
        "PwC acquired specialized AI consulting firm DataRobot Solutions",
        "Accenture launched autonomous business process platform",
        "IBM Consulting expanded sovereign AI capabilities",
        "BCG partnered with Google Cloud for enterprise AI solutions"
    ]
    
    for activity in activities:
        st.info(f"• {activity}")
        
with col2:
    st.markdown("**📈 Market Movements**")
    
    movements = [
        ("EY", "Increased AI consulting prices by 15%"),
        ("KPMG", "New office opening in Austin for AI services"),
        ("Capgemini", "Won $50M AI transformation contract"),
        ("Cognizant", "Launched new industry-specific AI solutions"),
        ("TCS", "Expanded European AI consulting team")
    ]
    
    for company, movement in movements:
        st.success(f"**{company}**: {movement}")

# AI-Powered Competitive Intelligence
st.markdown("### 🤖 AI Competitive Intelligence")

if st.button("Generate AI Competitive Analysis", type="primary"):
    with st.spinner("AI analyzing competitive landscape..."):
        try:
            # Create analysis prompt
            analysis_prompt = f"""
            Analyze the competitive landscape for Deloitte's AI consulting services based on this data:
            
            Top Competitors: {competitors_df['company_name'].tolist()[:5]}
            Market Dynamics: Growing demand for agentic AI, sovereign AI compliance
            Deloitte Position: #2 market position, strong AI capabilities
            
            Provide strategic insights on:
            1. Key competitive threats and opportunities
            2. Recommended strategic responses
            3. Market positioning advantages
            4. Innovation gaps to address
            
            Focus on 2026 AI priorities: agentic AI, physical AI, sovereign AI.
            Format response as JSON.
            """
            
            analysis = ai_services.analyze_competitive_landscape(analysis_prompt)
            
            if analysis:
                st.success("✅ AI Analysis Complete")
                
                tab1, tab2, tab3 = st.tabs(["🎯 Strategic Insights", "⚡ Recommendations", "🔮 Future Outlook"])
                
                with tab1:
                    st.markdown("**Key Competitive Insights:**")
                    insights = analysis.get('insights', 'Comprehensive competitive analysis completed')
                    st.info(insights)
                    
                    # Competitive advantage radar
                    categories = ['AI Expertise', 'Market Reach', 'Innovation', 'Client Trust', 'Pricing']
                    deloitte_scores = [85, 90, 82, 88, 75]
                    competitor_avg = [75, 85, 78, 80, 80]
                    
                    fig_radar = go.Figure()
                    fig_radar.add_trace(go.Scatterpolar(
                        r=deloitte_scores, theta=categories, fill='toself',
                        name='Deloitte', line_color='#86BC25'
                    ))
                    fig_radar.add_trace(go.Scatterpolar(
                        r=competitor_avg, theta=categories, fill='toself',
                        name='Competitor Average', line_color='#FF6B6B'
                    ))
                    fig_radar.update_layout(
                        polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
                        showlegend=True, title="Competitive Advantage Analysis"
                    )
                    st.plotly_chart(fig_radar, use_container_width=True)
                
                with tab2:
                    st.markdown("**Strategic Recommendations:**")
                    recommendations = analysis.get('recommendations', 'Strategic action items identified')
                    st.success(recommendations)
                    
                    # Action priority matrix
                    actions = ['Expand Agentic AI', 'Strengthen Sovereign AI', 'Partner Ecosystem', 'Pricing Strategy']
                    impact = [90, 85, 70, 60]
                    effort = [80, 70, 50, 40]
                    
                    fig_matrix = px.scatter(
                        x=effort, y=impact, text=actions,
                        title='Strategic Action Priority Matrix',
                        labels={'x': 'Implementation Effort', 'y': 'Business Impact'},
                        size=[20, 18, 15, 12]
                    )
                    fig_matrix.add_hline(y=75, line_dash="dash", line_color="gray")
                    fig_matrix.add_vline(x=65, line_dash="dash", line_color="gray")
                    st.plotly_chart(fig_matrix, use_container_width=True)
                
                with tab3:
                    st.markdown("**2026 Market Outlook:**")
                    outlook = analysis.get('outlook', 'Future market trends analyzed')
                    st.info(outlook)
                    
                    # Market growth projection
                    years = [2024, 2025, 2026, 2027]
                    ai_consulting_market = [45, 62, 85, 115]  # Billions
                    deloitte_projection = [8, 12, 18, 26]
                    
                    fig_growth = go.Figure()
                    fig_growth.add_trace(go.Scatter(
                        x=years, y=ai_consulting_market, mode='lines+markers',
                        name='Total Market ($B)', line=dict(color='#4ECDC4', width=3)
                    ))
                    fig_growth.add_trace(go.Scatter(
                        x=years, y=deloitte_projection, mode='lines+markers',
                        name='Deloitte Projection ($B)', line=dict(color='#86BC25', width=3)
                    ))
                    fig_growth.update_layout(
                        title='AI Consulting Market Growth Projection',
                        xaxis_title='Year', yaxis_title='Revenue ($B)'
                    )
                    st.plotly_chart(fig_growth, use_container_width=True)
                    
        except Exception as e:
            st.error(f"AI analysis temporarily unavailable: {str(e)}")
            # Fallback analysis
            st.info("Using fallback competitive intelligence...")
            st.markdown("""
            **🎯 Key Competitive Insights:**
            - Market consolidation accelerating with major acquisitions
            - Agentic AI becoming key differentiator for 2026
            - Sovereign AI compliance creating new market opportunities
            - Physical AI integration opening industrial consulting markets
            
            **⚡ Strategic Recommendations:**
            - Accelerate agentic AI platform development
            - Strengthen sovereign AI compliance capabilities
            - Expand partnership ecosystem for physical AI
            - Develop industry-specific AI solutions
            """)

# Threat Assessment Matrix
st.markdown("### ⚠️ Competitive Threat Assessment")

threat_data = competitors_df.copy()
threat_data['overall_threat'] = (
    threat_data['market_share'] * 0.3 +
    threat_data['ai_capability_score'] * 0.4 +
    threat_data['growth_rate'] * 0.3
)

col1, col2 = st.columns(2)

with col1:
    # Threat level distribution
    threat_data['threat_category'] = pd.cut(threat_data['overall_threat'], 
                          bins=[0, 30, 60, 100], 
                          labels=['Low', 'Medium', 'High'])
    threat_counts = threat_data['threat_category'].value_counts()
    
    fig_threat = px.pie(
        values=threat_counts.values, names=threat_counts.index,
        title='Competitive Threat Distribution',
        color_discrete_map={'High': '#FF6B6B', 'Medium': '#FFE66D', 'Low': '#4ECDC4'}
    )
    st.plotly_chart(fig_threat, use_container_width=True)

with col2:
    # Top threats table
    st.markdown("**🚨 Top Competitive Threats**")
    top_threats = threat_data.nlargest(5, 'overall_threat')[
        ['company_name', 'market_share', 'ai_capability_score', 'overall_threat']
    ]
    
    st.dataframe(
        top_threats,
        column_config={
            'overall_threat': st.column_config.ProgressColumn(
                'Threat Score', min_value=0, max_value=100
            ),
            'market_share': st.column_config.NumberColumn(
                'Market Share', format='%.1f%%'
            ),
            'ai_capability_score': st.column_config.NumberColumn(
                'AI Score', format='%.0f'
            )
        },
        hide_index=True
    )

# Export and Monitoring
st.markdown("### 📤 Export & Monitoring")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("Export Competitor Report"):
        csv = competitors_df.to_csv(index=False)
        st.download_button(
            label="Download Report CSV",
            data=csv,
            file_name=f"competitor_analysis_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )

with col2:
    if st.button("Set Alert Monitoring"):
        st.success("✅ Monitoring alerts configured")
        st.info("Will notify on: Market share changes >5%, New AI announcements, Pricing changes")

with col3:
    if st.button("Schedule Analysis"):
        st.success("✅ Analysis scheduled")
        st.info("Next automated analysis: Tomorrow 9:00 AM")

# Real-time Market Intelligence
st.markdown("### 📡 Real-time Market Intelligence")

if st.checkbox("Enable Real-time Monitoring"):
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**News Sentiment**")
        sentiment_score = np.random.uniform(0.6, 0.9)
        st.metric("Market Sentiment", f"{sentiment_score:.2f}", "+0.05")
        
    with col2:
        st.markdown("**Competitor Mentions**")
        mentions = np.random.randint(150, 300)
        st.metric("Social Mentions/Day", mentions, f"+{np.random.randint(10, 30)}")
        
    with col3:
        st.markdown("**Market Volatility**")
        volatility = np.random.choice(["Low", "Medium", "High"])
        st.metric("Volatility Index", volatility, "Stable")

st.markdown("---")
st.markdown("*Competitive intelligence powered by Deloitte's Agentic AI platform - Real-time monitoring of 150+ market sources*")
