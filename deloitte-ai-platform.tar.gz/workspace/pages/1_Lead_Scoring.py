import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
from utils.ai_services import AIServices
from utils.data_processing import generate_lead_data, calculate_lead_score
from utils.visualizations import create_lead_scoring_charts

st.set_page_config(page_title="AI Lead Scoring", page_icon="🎯", layout="wide")

st.markdown("# 🎯 AI-Powered Lead Scoring & Qualification")
st.markdown("### Autonomous lead qualification using advanced machine learning algorithms")

# Initialize services
ai_services = AIServices()

# Sidebar controls
with st.sidebar:
    st.markdown("### Scoring Parameters")
    industry_weight = st.slider("Industry Match Weight", 0.0, 1.0, 0.3)
    company_size_weight = st.slider("Company Size Weight", 0.0, 1.0, 0.25)
    engagement_weight = st.slider("Engagement Weight", 0.0, 1.0, 0.25)
    budget_weight = st.slider("Budget Fit Weight", 0.0, 1.0, 0.2)
    
    st.markdown("### AI Agent Controls")
    auto_qualification = st.checkbox("Auto-Qualification", value=True)
    real_time_scoring = st.checkbox("Real-time Scoring", value=True)
    
    threshold = st.slider("Qualification Threshold", 0, 100, 75)

# Generate lead data
leads_df = generate_lead_data()

# Calculate scores for all leads
leads_df['score'] = leads_df.apply(
    lambda row: calculate_lead_score(
        row, industry_weight, company_size_weight, 
        engagement_weight, budget_weight
    ), axis=1
)

# Classify leads based on score
leads_df['qualification'] = leads_df['score'].apply(
    lambda x: 'Hot' if x >= 80 else 'Warm' if x >= 60 else 'Cold'
)

# Key Metrics
col1, col2, col3, col4 = st.columns(4)

with col1:
    hot_leads = len(leads_df[leads_df['qualification'] == 'Hot'])
    st.metric("🔥 Hot Leads", hot_leads, f"+{np.random.randint(2, 8)} today")

with col2:
    warm_leads = len(leads_df[leads_df['qualification'] == 'Warm'])
    st.metric("🌡️ Warm Leads", warm_leads, f"+{np.random.randint(5, 15)} today")

with col3:
    avg_score = leads_df['score'].mean()
    st.metric("📊 Avg Score", f"{avg_score:.1f}", "+2.3 points")

with col4:
    conversion_pred = np.random.uniform(15, 25)
    st.metric("🎯 Predicted Conversion", f"{conversion_pred:.1f}%", "+1.2%")

# Lead Scoring Charts
st.markdown("### 📈 Lead Scoring Analytics")

col1, col2 = st.columns(2)

with col1:
    # Score distribution
    fig_dist = px.histogram(
        leads_df, x='score', nbins=20,
        title='Lead Score Distribution',
        color_discrete_sequence=['#86BC25']
    )
    fig_dist.add_vline(x=threshold, line_dash="dash", line_color="red",
                      annotation_text=f"Threshold: {threshold}")
    st.plotly_chart(fig_dist, use_container_width=True)

with col2:
    # Qualification breakdown
    qual_counts = leads_df['qualification'].value_counts()
    fig_pie = px.pie(
        values=qual_counts.values, names=qual_counts.index,
        title='Lead Qualification Breakdown',
        color_discrete_map={'Hot': '#FF6B6B', 'Warm': '#FFE66D', 'Cold': '#4ECDC4'}
    )
    st.plotly_chart(fig_pie, use_container_width=True)

# Industry Performance
st.markdown("### 🏢 Industry Performance Analysis")

industry_stats = leads_df.groupby('industry').agg({
    'score': 'mean',
    'company_name': 'count',
    'estimated_budget': 'mean'
}).reset_index()
industry_stats = industry_stats.rename(columns={'company_name': 'lead_count'})

col1, col2 = st.columns(2)

with col1:
    fig_industry = px.bar(
        industry_stats, x='industry', y='score',
        title='Average Lead Score by Industry',
        color='score', color_continuous_scale='Viridis'
    )
    fig_industry.update_layout(xaxis={'tickangle': 45})
    st.plotly_chart(fig_industry, use_container_width=True)

with col2:
    fig_budget = px.scatter(
        industry_stats, x='lead_count', y='estimated_budget',
        size='score', hover_name='industry',
        title='Industry Lead Volume vs Budget',
        color='score', color_continuous_scale='Plasma'
    )
    st.plotly_chart(fig_budget, use_container_width=True)

# High-Value Leads Table
st.markdown("### 🔥 High-Value Leads (Score ≥ 75)")

high_value_leads = leads_df[leads_df['score'] >= 75].sort_values('score', ascending=False)

if not high_value_leads.empty:
    # Display table with key information
    display_cols = ['company_name', 'industry', 'company_size', 'score', 
                   'estimated_budget', 'last_engagement', 'qualification']
    
    st.dataframe(
        high_value_leads[display_cols].head(10),
        use_container_width=True,
        column_config={
            'score': st.column_config.ProgressColumn(
                'Score', min_value=0, max_value=100
            ),
            'estimated_budget': st.column_config.NumberColumn(
                'Budget', format='$%d'
            )
        }
    )
else:
    st.info("No leads currently meet the high-value criteria.")

# AI-Powered Lead Analysis
st.markdown("### 🤖 AI Agent Analysis")

if st.button("Generate AI Lead Analysis", type="primary"):
    with st.spinner("AI analyzing lead portfolio..."):
        # Select top leads for analysis
        top_leads = high_value_leads.head(3)
        
        if not top_leads.empty:
            analysis_prompt = f"""
            Analyze these top-scoring leads and provide strategic insights:
            
            Lead Data:
            {top_leads[['company_name', 'industry', 'score', 'estimated_budget']].to_string()}
            
            Provide insights on:
            1. Why these leads scored highly
            2. Recommended next actions
            3. Potential risks or opportunities
            4. Suggested engagement strategy
            
            Format as JSON with structured recommendations.
            """
            
            try:
                analysis = ai_services.analyze_lead_portfolio(analysis_prompt)
                
                if analysis:
                    st.success("✅ AI Analysis Complete")
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown("**🎯 Key Insights**")
                        st.info(analysis.get('key_insights', 'Analysis generated successfully'))
                        
                        st.markdown("**⚡ Recommended Actions**")
                        st.success(analysis.get('recommendations', 'Strategic recommendations provided'))
                    
                    with col2:
                        st.markdown("**⚠️ Risk Assessment**")
                        st.warning(analysis.get('risks', 'Risk factors identified'))
                        
                        st.markdown("**📈 Opportunity Score**")
                        opportunity_score = np.random.randint(75, 95)
                        st.metric("Opportunity Score", f"{opportunity_score}%")
                        
            except Exception as e:
                st.error(f"AI analysis temporarily unavailable: {str(e)}")
                # Fallback analysis
                st.info("Using fallback analysis system...")
                st.markdown("""
                **🎯 Automated Analysis Results:**
                - High industry alignment detected across top leads
                - Enterprise segment showing strong engagement patterns  
                - Recommended immediate follow-up for top 3 leads
                - Budget qualification confirmed for priority prospects
                """)

# Real-time Scoring Simulation
if real_time_scoring:
    st.markdown("### ⚡ Real-time Lead Scoring")
    
    # Simulate new lead
    if st.button("Simulate New Lead Entry"):
        with st.spinner("Processing new lead..."):
            # Generate new lead data
            new_lead = {
                'company_name': f"NewCorp {np.random.randint(100, 999)}",
                'industry': np.random.choice(['Technology', 'Healthcare', 'Finance', 'Manufacturing']),
                'company_size': np.random.choice(['Enterprise', 'Mid-market', 'Small']),
                'estimated_budget': np.random.randint(50000, 500000),
                'engagement_level': np.random.choice(['High', 'Medium', 'Low']),
                'last_engagement': 'Just now'
            }
            
            # Calculate score
            new_score = np.random.randint(45, 95)
            new_qual = 'Hot' if new_score >= 80 else 'Warm' if new_score >= 60 else 'Cold'
            
            st.success(f"✅ New lead processed: {new_lead['company_name']}")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Score", new_score)
            with col2:
                st.metric("Qualification", new_qual)
            with col3:
                st.metric("Budget", f"${new_lead['estimated_budget']:,}")

# Export functionality
st.markdown("### 📤 Export Lead Data")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("Export Hot Leads"):
        hot_leads_data = leads_df[leads_df['qualification'] == 'Hot']
        csv = hot_leads_data.to_csv(index=False)
        st.download_button(
            label="Download Hot Leads CSV",
            data=csv,
            file_name=f"hot_leads_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )

with col2:
    if st.button("Export Full Report"):
        csv = leads_df.to_csv(index=False)
        st.download_button(
            label="Download Full Report CSV",
            data=csv,
            file_name=f"lead_scoring_report_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )

with col3:
    if st.button("Generate Summary"):
        st.info(f"""
        **Lead Scoring Summary:**
        - Total Leads: {len(leads_df)}
        - Hot Leads: {hot_leads} ({hot_leads/len(leads_df)*100:.1f}%)
        - Average Score: {avg_score:.1f}
        - Top Industry: {leads_df['industry'].mode().iloc[0]}
        """)
