import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
from utils.ai_services import AIServices
from utils.data_processing import generate_campaign_data, predict_campaign_performance

st.set_page_config(page_title="Campaign Optimization", page_icon="🚀", layout="wide")

st.markdown("# 🚀 AI-Powered Campaign Optimization")
st.markdown("### Predictive analytics and autonomous campaign management")

# Initialize services
ai_services = AIServices()

# Sidebar controls
with st.sidebar:
    st.markdown("### Campaign Parameters")
    budget_allocation = st.slider("Total Budget ($K)", 50, 1000, 250)
    campaign_duration = st.slider("Duration (weeks)", 2, 26, 12)
    target_audience_size = st.number_input("Target Audience", 10000, 1000000, 150000)
    
    st.markdown("### AI Optimization")
    auto_optimization = st.checkbox("Auto Budget Reallocation", value=True)
    real_time_bidding = st.checkbox("Real-time Bid Optimization", value=True)
    predictive_scaling = st.checkbox("Predictive Scaling", value=True)
    
    st.markdown("### Channel Preferences")
    channels = st.multiselect(
        "Marketing Channels",
        ["LinkedIn", "Google Ads", "Content Marketing", "Email", "Webinars", "Events"],
        default=["LinkedIn", "Google Ads", "Content Marketing"]
    )

# Generate campaign data
campaigns_df = generate_campaign_data()

# Key Performance Metrics
col1, col2, col3, col4 = st.columns(4)

with col1:
    total_roi = campaigns_df['roi'].mean()
    st.metric("📈 Average ROI", f"{total_roi:.1f}x", "+0.3x from AI optimization")

with col2:
    total_leads = campaigns_df['leads_generated'].sum()
    st.metric("🎯 Total Leads", f"{total_leads:,}", f"+{np.random.randint(50, 200)}")

with col3:
    avg_cpl = campaigns_df['cost_per_lead'].mean()
    st.metric("💰 Avg Cost/Lead", f"${avg_cpl:.0f}", f"-${np.random.randint(10, 30)}")

with col4:
    conversion_rate = campaigns_df['conversion_rate'].mean()
    st.metric("🔄 Conversion Rate", f"{conversion_rate:.1f}%", "+1.2%")

# Campaign Performance Dashboard
st.markdown("### 📊 Campaign Performance Dashboard")

col1, col2 = st.columns(2)

with col1:
    # ROI by Channel
    fig_roi = px.bar(
        campaigns_df, x='channel', y='roi',
        title='ROI by Marketing Channel',
        color='roi', color_continuous_scale='Viridis'
    )
    fig_roi.add_hline(y=total_roi, line_dash="dash", line_color="red",
                     annotation_text=f"Average ROI: {total_roi:.1f}x")
    st.plotly_chart(fig_roi, use_container_width=True)

with col2:
    # Lead Generation Efficiency
    fig_efficiency = px.scatter(
        campaigns_df, x='spend', y='leads_generated',
        size='roi', color='channel', hover_name='campaign_name',
        title='Campaign Efficiency: Spend vs Leads Generated',
        labels={'spend': 'Campaign Spend ($)', 'leads_generated': 'Leads Generated'}
    )
    st.plotly_chart(fig_efficiency, use_container_width=True)

# Predictive Campaign Performance
st.markdown("### 🔮 Predictive Campaign Modeling")

if st.button("Run AI Performance Prediction", type="primary"):
    with st.spinner("AI analyzing campaign performance patterns..."):
        
        # Generate prediction data
        prediction_data = predict_campaign_performance(
            budget_allocation * 1000, campaign_duration, target_audience_size, channels
        )
        
        tab1, tab2, tab3 = st.tabs(["📈 Performance Forecast", "💰 Budget Optimization", "🎯 Channel Mix"])
        
        with tab1:
            # Performance forecast timeline
            weeks = list(range(1, campaign_duration + 1))
            cumulative_leads = np.cumsum([prediction_data['weekly_leads']] * campaign_duration)
            cumulative_spend = np.cumsum([budget_allocation * 1000 / campaign_duration] * campaign_duration)
            
            fig_forecast = go.Figure()
            fig_forecast.add_trace(go.Scatter(
                x=weeks, y=cumulative_leads, mode='lines+markers',
                name='Predicted Leads', line=dict(color='#86BC25', width=3)
            ))
            
            # Add confidence interval
            upper_bound = cumulative_leads * 1.2
            lower_bound = cumulative_leads * 0.8
            fig_forecast.add_trace(go.Scatter(
                x=weeks + weeks[::-1], y=list(upper_bound) + list(lower_bound[::-1]),
                fill='toself', fillcolor='rgba(134, 188, 37, 0.2)',
                line=dict(color='rgba(255,255,255,0)'),
                name='Confidence Interval'
            ))
            
            fig_forecast.update_layout(
                title='Predicted Campaign Performance Over Time',
                xaxis_title='Week', yaxis_title='Cumulative Leads'
            )
            st.plotly_chart(fig_forecast, use_container_width=True)
            
            # Key predictions
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Predicted Total Leads", f"{prediction_data['total_leads']:,}")
            with col2:
                st.metric("Expected ROI", f"{prediction_data['expected_roi']:.1f}x")
            with col3:
                st.metric("Confidence Level", f"{prediction_data['confidence']:.0f}%")
        
        with tab2:
            # Budget optimization recommendations
            st.markdown("**🎯 AI-Optimized Budget Allocation**")
            
            budget_recommendations = {
                'LinkedIn': 0.35,
                'Google Ads': 0.30,
                'Content Marketing': 0.20,
                'Email': 0.10,
                'Events': 0.05
            }
            
            budget_df = pd.DataFrame(list(budget_recommendations.items()))
            budget_df.columns = ['Channel', 'Recommended_Allocation']
            budget_df['Budget_Amount'] = budget_df['Recommended_Allocation'] * budget_allocation * 1000
            
            fig_budget = px.pie(
                budget_df, values='Recommended_Allocation', names='Channel',
                title='AI-Recommended Budget Distribution'
            )
            st.plotly_chart(fig_budget, use_container_width=True)
            
            st.dataframe(
                budget_df,
                column_config={
                    'Recommended_Allocation': st.column_config.ProgressColumn(
                        'Allocation %', min_value=0, max_value=1
                    ),
                    'Budget_Amount': st.column_config.NumberColumn(
                        'Budget Amount', format='$%d'
                    )
                }
            )
        
        with tab3:
            # Channel performance analysis
            st.markdown("**📊 Channel Performance Analysis**")
            
            channel_data = {
                'Channel': ['LinkedIn', 'Google Ads', 'Content Marketing', 'Email', 'Events'],
                'Expected_CPL': [85, 65, 120, 45, 200],
                'Expected_Conversion': [4.2, 2.8, 6.1, 8.5, 12.3],
                'Audience_Fit': [92, 78, 85, 88, 95]
            }
            
            channel_df = pd.DataFrame(channel_data)
            
            fig_channel = px.scatter(
                channel_df, x='Expected_CPL', y='Expected_Conversion',
                size='Audience_Fit', hover_name='Channel',
                title='Channel Performance: Cost vs Conversion Rate',
                labels={'Expected_CPL': 'Cost per Lead ($)', 'Expected_Conversion': 'Conversion Rate (%)'}
            )
            st.plotly_chart(fig_channel, use_container_width=True)

# Real-time Campaign Monitoring
st.markdown("### ⚡ Real-time Campaign Monitoring")

if auto_optimization:
    st.success("🤖 AI Auto-Optimization: ACTIVE")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Recent AI Actions**")
        actions = [
            "Increased LinkedIn budget by 15%",
            "Optimized ad targeting for healthcare sector",
            "Adjusted bidding strategy for peak hours",
            "Reallocated budget from underperforming campaigns"
        ]
        for action in actions:
            st.info(f"• {action}")
    
    with col2:
        st.markdown("**Performance Alerts**")
        st.warning("⚠️ Campaign 'AI Transformation' below target CTR")
        st.success("✅ 'Digital Strategy' campaign exceeding goals by 23%")
        st.info("📊 Budget utilization at 67% for Q4")
    
    with col3:
        st.markdown("**Optimization Metrics**")
        st.metric("AI Confidence", "89%", "+3%")
        st.metric("Auto-adjustments Today", "12", "+4")
        st.metric("Performance Improvement", "+34%", "vs manual campaigns")

# Campaign A/B Testing
st.markdown("### 🧪 AI-Powered A/B Testing")

col1, col2 = st.columns(2)

with col1:
    st.markdown("**Active A/B Tests**")
    
    ab_tests = pd.DataFrame({
        'Test': ['Landing Page Design', 'Email Subject Lines', 'Ad Creative', 'CTA Placement'],
        'Status': ['Running', 'Completed', 'Running', 'Analysis'],
        'Confidence': [73, 95, 82, 68],
        'Winning_Variant': ['B', 'A', 'C', 'TBD']
    })
    
    st.dataframe(
        ab_tests,
        column_config={
            'Confidence': st.column_config.ProgressColumn(
                'Statistical Confidence', min_value=0, max_value=100
            )
        }
    )

with col2:
    # A/B Test Results Visualization
    test_results = pd.DataFrame({
        'Variant': ['Control', 'Variant A', 'Variant B', 'Variant C'],
        'Conversion_Rate': [2.3, 2.8, 3.1, 2.6],
        'Sample_Size': [1000, 950, 1020, 980]
    })
    
    fig_ab = px.bar(
        test_results, x='Variant', y='Conversion_Rate',
        title='A/B Test Results: Ad Creative Performance',
        color='Conversion_Rate', color_continuous_scale='Viridis'
    )
    st.plotly_chart(fig_ab, use_container_width=True)

# Campaign Creation Assistant
st.markdown("### 🎨 AI Campaign Creation Assistant")

if st.button("Generate New Campaign", type="primary"):
    with st.spinner("AI creating optimized campaign..."):
        try:
            campaign_prompt = f"""
            Create an AI consulting marketing campaign for Deloitte targeting:
            - Budget: ${budget_allocation}K
            - Duration: {campaign_duration} weeks
            - Channels: {', '.join(channels)}
            - Focus: 2026 AI priorities (agentic AI, physical AI, sovereign AI)
            
            Provide:
            1. Campaign concept and messaging
            2. Channel-specific content recommendations
            3. Timeline and milestones
            4. Success metrics and KPIs
            
            Format as JSON with detailed recommendations.
            """
            
            campaign_concept = ai_services.generate_campaign_strategy(campaign_prompt)
            
            if campaign_concept:
                st.success("✅ AI Campaign Generated")
                
                tab1, tab2, tab3 = st.tabs(["🎯 Campaign Concept", "📝 Content Strategy", "📈 Success Metrics"])
                
                with tab1:
                    st.markdown("**Campaign Concept:**")
                    st.info(campaign_concept.get('concept', 'Innovative AI transformation campaign created'))
                    
                    st.markdown("**Key Messages:**")
                    messages = campaign_concept.get('messages', [
                        'Transform your business with agentic AI',
                        'Ensure compliance with sovereign AI solutions',
                        'Bridge digital and physical worlds with AI'
                    ])
                    for msg in messages:
                        st.markdown(f"• {msg}")
                
                with tab2:
                    st.markdown("**Content Recommendations:**")
                    st.success(campaign_concept.get('content_strategy', 'Comprehensive content strategy developed'))
                    
                    # Content calendar preview
                    content_calendar = pd.DataFrame({
                        'Week': range(1, min(campaign_duration, 8) + 1),
                        'LinkedIn': ['Thought leadership post'] * min(campaign_duration, 7),
                        'Content': ['Blog article', 'Case study', 'Whitepaper', 'Video', 'Infographic', 'Webinar', 'Podcast'],
                        'Email': ['Newsletter', 'Follow-up', 'Nurture', 'Event invite', 'Success story', 'Trends update', 'Survey']
                    })
                    st.dataframe(content_calendar[:7])
                
                with tab3:
                    st.markdown("**Success Metrics & KPIs:**")
                    metrics = campaign_concept.get('kpis', 'Comprehensive KPI framework established')
                    st.info(metrics)
                    
                    # Predicted performance
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Target Leads", "1,250")
                    with col2:
                        st.metric("Expected ROI", "2.8x")
                    with col3:
                        st.metric("Success Probability", "85%")
                        
        except Exception as e:
            st.error(f"Campaign generation temporarily unavailable: {str(e)}")
            st.info("Using template campaign generator...")
            st.markdown("""
            **🎯 Generated Campaign: "AI Leadership 2026"**
            
            **Concept:** Position Deloitte as the leader in next-generation AI consulting
            
            **Key Messages:**
            • Transform operations with autonomous AI agents
            • Ensure compliance with sovereign AI frameworks  
            • Bridge digital-physical worlds through AI integration
            
            **Content Strategy:**
            • LinkedIn: Executive thought leadership series
            • Content Marketing: AI transformation case studies
            • Email: Industry-specific AI insights newsletter
            """)

# Export and Reporting
st.markdown("### 📤 Campaign Reports & Export")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("Generate Performance Report"):
        st.success("✅ Comprehensive performance report generated")
        
        report_data = campaigns_df.to_dict('records')
        st.download_button(
            label="Download Campaign Report",
            data=pd.DataFrame(report_data).to_csv(index=False),
            file_name=f"campaign_report_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )

with col2:
    if st.button("Schedule Optimization"):
        st.success("✅ AI optimization scheduled")
        st.info("Next optimization: Every 4 hours")

with col3:
    if st.button("Export Predictions"):
        prediction_data_default = {'total_leads': 1250, 'expected_roi': 2.8, 'confidence': 85}
        prediction_csv = pd.DataFrame([prediction_data_default]).to_csv(index=False)
        st.download_button(
            label="Download Predictions",
            data=prediction_csv,
            file_name=f"campaign_predictions_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )

st.markdown("---")
st.markdown("*Campaign optimization powered by Deloitte's predictive AI engine - Delivering 34% better performance than traditional campaigns*")
