# Deloitte AI Marketing Intelligence Platform

## Overview

This is a Streamlit-based AI Marketing Intelligence Platform designed for Deloitte's consulting practice. The platform provides comprehensive marketing analytics and client acquisition tools, featuring lead scoring, competitor analysis, campaign optimization, sentiment analysis, market intelligence, and automated proposal generation. The application focuses on Deloitte's 2026 AI priorities including agentic AI, physical AI, and sovereign AI consulting services.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Updates (August 2025)

- Fixed all LSP diagnostics and code errors for error-free operation
- Improved OpenAI API key handling with better user guidance
- Enhanced user experience with clear setup instructions
- Added comprehensive API setup guide and troubleshooting
- Optimized for Deloitte internship application presentation
- All 6 AI modules fully functional and professionally presented

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit for web interface with custom CSS styling using Deloitte branding colors
- **Layout Pattern**: Multi-page application with sidebar navigation and wide layout configuration
- **Visualization**: Plotly Express and Plotly Graph Objects for interactive charts and dashboards
- **Styling**: Custom CSS with Deloitte green branding (#86BC25) and responsive design components

### Backend Architecture
- **Core Application**: Single `app.py` entry point with modular page structure in `/pages` directory
- **Service Layer**: Centralized AI services through `AIServices` class for OpenAI API interactions
- **Data Processing**: Utility modules for lead generation, scoring algorithms, and metrics calculation
- **Visualization Engine**: Dedicated module for chart creation and dashboard components

### AI Integration
- **Primary AI Service**: OpenAI GPT-4o integration for lead analysis, market intelligence, and proposal generation
- **AI Agent Architecture**: Multiple specialized AI agents for different business functions (lead scoring, competitor analysis, sentiment monitoring)
- **Prompt Engineering**: Structured system prompts for business-specific AI responses with JSON formatting

### Data Management
- **Data Generation**: Programmatic generation of realistic business data for leads, campaigns, and market intelligence
- **Schema Definition**: Structured data schemas for leads, market data, and competitor information
- **Real Market Data**: Integration of actual Deloitte market research and industry statistics

### Scoring and Analytics
- **Lead Scoring Algorithm**: Weighted scoring system based on industry fit, company size, engagement level, and budget
- **Sentiment Analysis**: TextBlob integration for client feedback and social media sentiment processing
- **Predictive Analytics**: Campaign performance prediction and ROI modeling

## External Dependencies

### AI Services
- **OpenAI API**: GPT-4o model for natural language processing, analysis, and content generation
- **TextBlob**: Natural language processing library for sentiment analysis

### Visualization and UI
- **Streamlit**: Web application framework and hosting platform
- **Plotly**: Interactive charting and visualization library (Express and Graph Objects)

### Data Processing
- **Pandas**: Data manipulation and analysis
- **NumPy**: Numerical computing for calculations and data generation

### Development Dependencies
- **Python Standard Library**: datetime, json, os, random modules for core functionality
- **Environment Variables**: OpenAI API key configuration through environment variables

### Market Data Sources
- **Deloitte Research**: Real market intelligence data for AI consulting industry
- **Industry Reports**: Market sizing and growth projections for AI services
- **Competitive Intelligence**: Big 4 consulting and tech giant market positioning data