# OpenAI API Key Setup Guide

## Step-by-Step Instructions

### 1. Create OpenAI Account
- Visit https://platform.openai.com
- Click "Sign up" and create your account
- Verify your email address

### 2. Add Billing Information
- Go to Settings → Billing
- Add a payment method (credit card)
- Add $5-10 credits (enough for extensive testing)

### 3. Create API Key
- Navigate to API Keys section
- Click "Create new secret key"
- Name it "Deloitte-Marketing-Platform"
- Copy the key (starts with sk-...)

### 4. Add Key to Replit
- In your Replit project, look for the Secrets tab (🔒 icon in sidebar)
- Click "New Secret"
- Key: `OPENAI_API_KEY`
- Value: Paste your copied API key
- Click "Add Secret"

### 5. Restart Application
- The application will automatically detect the new API key
- You'll see "AI Features: Active" in the sidebar

## What AI Features Will Be Unlocked

✅ **Lead Scoring Intelligence**
- AI-powered lead analysis and recommendations
- Strategic insights based on Deloitte's 2026 AI priorities
- Risk assessment and opportunity identification

✅ **Competitive Analysis**
- Market positioning insights
- Threat assessment with strategic recommendations
- Competitive intelligence reports

✅ **Campaign Optimization**
- AI-driven campaign strategy generation
- ROI predictions and budget optimization
- Performance forecasting

✅ **Advanced Sentiment Analysis**
- Context-aware sentiment insights
- Improvement recommendations with ROI impact
- Strategic action plans

✅ **Market Intelligence**
- Comprehensive market analysis
- Technology trend assessment
- Geographic opportunity mapping

✅ **AI Proposal Generator**
- Fully automated proposal creation
- Custom recommendations based on client needs
- Investment analysis and timeline planning

## Cost Estimates
- Basic testing: $2-5 per month
- Heavy usage: $10-20 per month
- Each AI analysis costs approximately $0.01-0.05

## Security Notes
- Your API key is stored securely in Replit's encrypted secrets
- Never share your API key with others
- You can regenerate keys anytime in OpenAI dashboard

## Troubleshooting
If you see errors after adding the key:
1. Check the key format (should start with sk-)
2. Ensure billing is set up in OpenAI
3. Restart the Streamlit application
4. Contact support if issues persist

## Ready to Use!
Once set up, all AI features will work automatically. The platform will show strategic insights, generate custom reports, and provide advanced analysis for your Deloitte internship application.